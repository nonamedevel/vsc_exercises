

const fs = require('fs')
const path = require('path')

function getFilesRecursively(rootDir) {
    const files = []
    function walk(currentDir) {
        const dirItems = fs.readdirSync(currentDir)
        for (const item of dirItems) {
            const fullPath = path.join(currentDir, item)
            const relativePath = path.relative(rootDir, fullPath)
            if (fs.statSync(fullPath).isDirectory()) {
                walk(fullPath)
            } else {
                files.push(relativePath)
            }
        }
    }
    walk(rootDir)
    return files
}

const fileList = getFilesRecursively('C:/vscode-main')
console.log(fileList)

