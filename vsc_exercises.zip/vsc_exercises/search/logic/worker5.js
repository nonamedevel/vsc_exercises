
globalThis.onmessage = function (e) {
    globalThis.postMessage(e.data + 10)
}
