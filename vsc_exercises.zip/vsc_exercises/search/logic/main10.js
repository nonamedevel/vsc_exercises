
// src\vs\base\common\worker\webWorker.ts
const MessageType = { // 36
	Request: 0,
	Reply: 1,
	SubscribeEvent: 2,
	Event: 3,
	UnsubscribeEvent: 4,
}

// entry point
function test() {
    const worker = new Worker('search/logic/worker10.js')
    worker.onmessage = (e) => {
        console.log(e.data)
    }
    console.log('Worker started!')
    
    const sendBtn = document.createElement('button')
    sendBtn.textContent = 'Send'
    document.body.append(sendBtn)
    sendBtn.addEventListener('click', () => {
        worker.postMessage({
            type: MessageType.Request,
            req: "6",
            channel: "default",
            method: "$searchDirectory",
            args: [
                {},
                {
                    folderQueries: {
                        contentPattern: {
                            pattern: 'abc',
                            isRegExp: false,
                            isCaseSensitive: true,
                            isWordMatch: true,
                        }
                    }
                },
                {
                    folder: {
                        path: '/vscode-main'
                    }
                }
            ]
        })
    })
}

test()
