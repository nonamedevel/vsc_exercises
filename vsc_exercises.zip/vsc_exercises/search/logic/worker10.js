
/*
    out\vs\workbench\workbench.web.main.internal.js
    out\vs\workbench\services\search\worker\localFileSearchMain.js


    src\vs\base\common\errors.ts
    src\vs\base\common\collections.ts       ?
    src\vs\base\common\arraysFind.ts
    ...
    src\vs\base\common\strings.ts


*/

// src\vs\base\common\worker\webWorker.ts
const MessageType = { // 36
	Request: 0,
	Reply: 1,
	SubscribeEvent: 2,
	Event: 3,
	UnsubscribeEvent: 4,
}
class ReplyMessage { // 53
    constructor(vsWorker, seq, res, err) {
        this.type = MessageType.Reply
        this.vsWorker = vsWorker
        this.seq = seq
        this.res = res
        this.err = err
    }
}
class WebWorkerProtocol { // 100
	constructor(handler) {
		this._workerId = -1;
		this._handler = handler;
    }
    handleMessage(message) { // 150
        this._handleMessage(message)
    }
    _handleMessage(msg) { // 183
		switch (msg.type) {
			case MessageType.Reply:
				return this._handleReplyMessage(msg)
			case MessageType.Request:
				return this._handleRequestMessage(msg)
		}
    }
    _handleReplyMessage() {

    }
    _handleRequestMessage(requestMessage) { // 223
        const req = requestMessage.req
        const result = this._handler.handleMessage(requestMessage.channel, requestMessage.method, requestMessage.args);
        result.then((r) => {
			this._send(new ReplyMessage(this._workerId, req, r, undefined));
		})
    }
    _send(msg) { // 262
        this._handler.sendMessage(msg)
    }
} // 278
class WebWorkerServer { // 438
    constructor(postMessage, requestHandlerFactory) { // 445
        this._protocol = new WebWorkerProtocol({
			sendMessage: (msg, transfer) => {
				postMessage(msg, transfer)
			},
			handleMessage: (channel, method, args) => this._handleMessage(channel, method, args),
			handleEvent: (channel, eventName, arg) => this._handleEvent(channel, eventName, arg)
		})
        this.requestHandler = requestHandlerFactory(this)
    }
    onmessage(msg) { // 456
        this._protocol.handleMessage(msg)
    }
    _handleMessage(channel, method, args) {
        const requestHandler = this.requestHandler
        const fn = requestHandler[method]
        const temp = fn.apply(requestHandler, args)
        return Promise.resolve(temp)
    }
} // 524

// src\vs\base\common\worker\webWorkerBootstrap.ts
function initialize(factory) { // 19
    const webWorkerServer = new WebWorkerServer(
        msg => globalThis.postMessage(msg),
        (workerServer) => factory(workerServer)
    )
	globalThis.onmessage = (e) => {
		webWorkerServer.onmessage(e.data)
	}
}
function bootstrapWebWorker(factory) { // 37
	globalThis.onmessage = (_e) => {
        initialize(factory)
	}
}

// src\vs\workbench\services\search\common\getFileResults.ts
const getFileResults = (bytes, pattern) => {

}

// src\vs\workbench\services\search\worker\localFileSearch.ts
const time = async (name, task) => { // 37
    return task()
}
function create(workerServer) { // 51
    return new LocalFileSearchWorker()
}
class LocalFileSearchWorker { // 55
    $searchDirectory(handle, query, folderQuery, ignorePathCasing, queryId) { // 110
        return time('searchInFiles', async () => {
            const processFile = async (file) => {
                const contents = await file.resolve()
                const bytes = new Uint8Array(contents)
                const fileResults = getFileResults(bytes, pattern)
                if (fileResults.length) {
                    const match = 'match'
                    results.push(match)
                }
            }
            return query.contentPattern.pattern + '!!'
        })
    }
}

// src\vs\workbench\services\search\worker\localFileSearchMain.ts
/*
    TODO: Why is the first message sent to the worker ignored?
*/
// bootstrapWebWorker(create)
initialize(create)
