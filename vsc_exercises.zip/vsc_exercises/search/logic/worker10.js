
/*
    out\vs\workbench\workbench.web.main.internal.js
    out\vs\workbench\services\search\worker\localFileSearchMain.js


    src\vs\base\common\errors.ts
    src\vs\base\common\collections.ts       ?
    src\vs\base\common\arraysFind.ts
    ...
    src\vs\base\common\strings.ts


*/

// src\vs\base\common\worker\webWorker.ts
const MessageType = { // 36
	Request: 0,
	Reply: 1,
	SubscribeEvent: 2,
	Event: 3,
	UnsubscribeEvent: 4,
}
class WebWorkerProtocol { // 100
    handleMessage(message) { // 150
        this._handleMessage(message)
    }
    _handleMessage(msg) { // 183
		switch (msg.type) {
			case MessageType.Reply:
				return this._handleReplyMessage(msg)
			case MessageType.Request:
				return this._handleRequestMessage(msg)
		}
    }
    _handleReplyMessage() {

    }
    _handleRequestMessage(requestMessage) { // 223
        console.log(requestMessage)
    }
} // 278
class WebWorkerServer { // 438
    constructor() {
        this._protocol = new WebWorkerProtocol()
    }
    onmessage(msg) { // 456
        this._protocol.handleMessage(msg)
    }
} // 524

// src\vs\base\common\worker\webWorkerBootstrap.ts
function initialize(factory) { // 19
    const webWorkerServer = new WebWorkerServer()
	globalThis.onmessage = (e) => {
		webWorkerServer.onmessage(e.data)
	}
}
function bootstrapWebWorker(factory) { // 37
	globalThis.onmessage = (_e) => {
        initialize(factory)
	}
}


// src\vs\workbench\services\search\worker\localFileSearch.ts
function create(workerServer) {

}


// src\vs\workbench\services\search\worker\localFileSearchMain.ts
/*
    TODO: Why is the first message sent to the worker ignored?
*/
// bootstrapWebWorker(create)
initialize()
