
/*
    apply() vs call()
*/
function test1() {
    function print(...msg) {
        console.log(...msg)
    }
    print('hello', 'world')
    print.call(null, 'hello', 'world')
    print.apply(null, ['hello', 'world'])
}

/*
    async
*/
async function test1() {
    async function getNum() {
        return 5
    }
    console.log(await getNum() + 10)
}

/*
    Resolved promise
*/
function test1() {
    const promise = Promise.resolve(5)
    console.log(promise + 30)
    promise.then((num) => {
        console.log(num + 30)
    })
}

/*
    Multiple promises
*/
function test1() {
    async function getNum() {
        return 5
    }
    const promise = Promise.resolve(getNum())
    promise.then((num) => {
        console.log(num + 20)
    })
}

/*
    then() waits for all promises
*/
function test() {
    const innerPromise = new Promise((res) => {
        console.log('innerPromise')
        setTimeout(() => {
            console.log('innerPromise setTimeout')
            res(6)
        }, 1000)
    })
    const outerPromise = new Promise((res) => {
        console.log('outerPromise')
        setTimeout(() => {
            console.log('outerPromise setTimeout')
            res(innerPromise)
        }, 2000)
    })
    outerPromise.then((num) => {
        console.log(num + 40)
    })
}

async function test() {
    const outerPromise = new Promise((res) => {
        console.log('outerPromise')
        setTimeout(() => {
            console.log('outerPromise setTimeout')
            res(new Promise((res) => {
                console.log('innerPromise')
                setTimeout(() => {
                    console.log('innerPromise setTimeout')
                    res(6)
                }, 5000)
            }))
        }, 5000)
    })
    // outerPromise.then((num) => {
    //     console.log(num + 60)
    // })

    const num = await outerPromise
    console.log(num + 70)
}

test()
