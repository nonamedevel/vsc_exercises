/*
    Starting point
*/

const worker = new Worker('search/logic/worker5.js')
worker.onmessage = (e) => {
    console.log(e.data)
}
console.log('Worker started!')

const sendBtn = document.createElement('button')
sendBtn.textContent = 'Send'
document.body.append(sendBtn)
sendBtn.addEventListener('click', () => {
    worker.postMessage(5)
})
