
/*
    out\vs\workbench\workbench.web.main.internal.js
    out\vs\workbench\services\search\worker\localFileSearchMain.js


    src\vs\base\common\errors.ts
    src\vs\base\common\collections.ts       ?
    src\vs\base\common\arraysFind.ts
    ...
    src\vs\base\common\strings.ts

*/

// src\vs\base\common\worker\webWorkerBootstrap.ts
function bootstrapWebWorker(factory) {

}


// src\vs\workbench\services\search\worker\localFileSearch.ts
function create(workerServer) {

}


// src\vs\workbench\services\search\worker\localFileSearchMain.ts
bootstrapWebWorker(create)
