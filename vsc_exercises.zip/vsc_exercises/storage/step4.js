/*
    Update IndexedDBFileSystemProvider, add FileService

    Where does 'untitled:Untitled-1 {"typeId":""}\nabc' come from?
*/

// src\vs\base\browser\indexedDB.ts
class IndexedDB {
    static async create(name, version, stores) { // 25
        const database = await IndexedDB.openDatabase(name, version, stores)
		return new IndexedDB(database, name)
    }
    static async openDatabase(name, version, stores) { // 30
        return await IndexedDB.doOpenDatabase(name, version, stores)
    }
    static doOpenDatabase(name, version, stores) {
        return new Promise((c, e) => {
            const request = indexedDB.open(name, version)
            request.onsuccess = () => {
				const db = request.result
                c(db)
            }
            request.onupgradeneeded = () => {
				const db = request.result
				for (const store of stores) {
                    db.createObjectStore(store)
				}
            }
        })
    }
	constructor(database) {
		this.database = database
	}
}

// src\vs\platform\files\browser\indexedDBFileSystemProvider.ts
class IndexedDBFileSystemProvider { // kRi = class
    constructor(scheme, indexedDB, store) { // 173
        this.indexedDB = indexedDB
        this.store = store
        this.fileWriteBatch = []
    }
    writeFile(resource, content) { // 258
        this.bulkWrite([[resource, content]])
    }
    bulkWrite(files) { // 382
        files.forEach(
            ([resource, content]) => this.fileWriteBatch.push({ content, resource })
        )
        this.writeMany()
    }
    writeMany() { // 395
        const tx = this.indexedDB.database.transaction(this.store, 'readwrite')
        const objectStore = tx.objectStore(this.store)
        const entry = this.fileWriteBatch[0]
        objectStore.put(entry.content, entry.resource.path)
        tx.oncomplete = () => {
            console.log('Done')
        }
    }
}

// src\vs\platform\files\common\fileService.ts
class FileService {
    doWriteUnbufferedQueued(provider, resource) { // 1363
        const str = 'untitled:Untitled-1 {"typeId":""}\nabc'
        const content = new Uint8Array(str.length)
        for (let i = 0; i < str.length; i++) {
            content[i] = str.charCodeAt(i)
        }
        const buffer = {
            buffer: content
        }
        provider.writeFile(resource, buffer.buffer) // 1376
    }
}

// entry point
async function main() {
    const userDataStore = 'vscode-userdata-store'
    const indexedDB = await IndexedDB.create(
        'vscode-web-db', 
        3, 
        [userDataStore]
    )
    const provider = new IndexedDBFileSystemProvider(undefined, indexedDB, userDataStore)
    const resource = {
        path: '/User/Backups/-2ad0bbb/untitled/-7f9c1a2e'
    }
    const fileService = new FileService()
    fileService.doWriteUnbufferedQueued(provider, resource)
}

function test() {
    const req = indexedDB.deleteDatabase('vscode-web-db')
    req.onsuccess = () => {
        main()
    }
}

function test1() {
    main()
}

test()
