/*
    Scenario: User creates a new text file with the text 'abc'.
    How is this file stored in a browser version of the editor?
*/

// [117, 110, 116, 105, 116, 108, 101, 100, 58, 85, 110, 116, 105, 116, 108, 101, 100, 45, 49, 32, 123, 34, 116, 121, 112, 101, 73, 100, 34, 58, 34, 34, 125, 10, 97, 98, 99].map(x => String.fromCharCode(x)).join('')

// (await indexedDB.databases()).forEach(db => indexedDB.deleteDatabase(db.name))

// indexedDB.deleteDatabase('abc').onsuccess = (event) => {
//     console.log('done')
// }