/*
    How are temp files stored in a browser version?
*/

// [117, 110, 116, 105, 116, 108, 101, 100, 58, 85, 110, 116, 105, 116, 108, 101, 100, 45, 50, 32, 123, 34, 116, 121, 112, 101, 73, 100, 34, 58, 34, 34, 125, 10, 104, 101, 108, 108, 111, 32, 116, 104, 101, 114, 101].map(x => String.fromCharCode(x)).join('')

// (await indexedDB.databases()).forEach(db => indexedDB.deleteDatabase(db.name))


// src\vs\platform\files\browser\indexedDBFileSystemProvider.ts
class IndexedDBFileSystemProvider { // kRi = class
    writeFile() { // 258
        console.log(444)
    }
}


// src\vs\platform\files\common\fileService.ts
class FileService {
    constructor() {
        this.provider = new Map()
    }
    registerProvider(scheme, provider) {
        this.provider.set(scheme, provider);
    }
    withProvider(resource) { // 137
        const provider = this.provider.get(resource.scheme);
        return provider;
    }
    withWriteProvider(resource) { // 169
        const provider = this.withProvider(resource);
        return provider
    }
    writeFile(resource) { // 380
        const provider = this.withWriteProvider(resource)
        this.doWriteUnbuffered(provider, resource)
    }
    doWriteUnbuffered(provider) { // 1359
        return this.writeQueue.queueFor(
            resource, 
            () => this.doWriteUnbufferedQueued(
                provider, 
                resource, 
                options, 
                bufferOrReadableOrStreamOrBufferedStream
            ), 
            this.getExtUri(provider).providerExtUri
        );
    }
    doWriteUnbufferedQueued(provider) { // 1363
        provider.writeFile()
    }
}

// src\vs\base\browser\indexedDB.ts
class IndexedDB {
    static async create(name, version, stores) { // 25
        const database = await IndexedDB.openDatabase(name, version, stores);
		return new IndexedDB(database, name);
    }
    static async openDatabase(name, version, stores) { // 30
        return await IndexedDB.doOpenDatabase(name, version, stores)
    }
    static doOpenDatabase(name, version, stores) {
        return new Promise((c, e) => {
            const request = indexedDB.open(name, version)
            request.onsuccess = () => {
				const db = request.result;
                c(db);
            }
        })
    }
}

// src\vs\base\common\network.ts
const Schemas = {
    vscodeUserData: 'vscode-userdata'
}

// src\vs\workbench\browser\web.main.ts
class BrowserMain {
    async registerIndexedDBFileSystemProviders(fileService) {
		const userDataStore = 'vscode-userdata-store';
        const indexedDB = await IndexedDB.create(
            'vscode-web-db', 
            3, 
            [userDataStore]
        );
        const userDataProvider = new IndexedDBFileSystemProvider(Schemas.vscodeUserData, indexedDB, userDataStore, true);
		fileService.registerProvider(Schemas.vscodeUserData, userDataProvider);
    }
}


// src\vs\workbench\services\workingCopy\common\workingCopyBackupService.ts
class WorkingCopyBackupService { // 119
    constructor(backupWorkspaceHome) {
        this.impl = this.initialize(backupWorkspaceHome)
    }
	backup(identifier, content, versionId, meta, token) { // 159
		return this.impl.backup(identifier, content, versionId, meta, token);
	}
} // 186
class WorkingCopyBackupServiceImpl { // 188
    constructor(fileService) {
        this.fileService = fileService
    }
    backup(identifier) { // 236
        const backupResource = this.toBackupResource(identifier);
        return this.ioOperationQueues.queueFor(backupResource, async () => {
            this.fileService.writeFile(backupResource, backupBuffer);
        })
    }
    toBackupResource(identifier) { // 516

    }
} // 523

// src\vs\workbench\services\workingCopy\common\workingCopyBackupTracker.ts
class WorkingCopyBackupTracker {
    constructor(workingCopyBackupService, workingCopyService) {
        this.workingCopyBackupService = workingCopyBackupService
        this.workingCopyService = workingCopyService
        this.registerListeners();
    }
    registerListeners() { // 52
        this.workingCopyService.onDidChangeContent(workingCopy => this.onDidChangeContent(workingCopy))
    }
    onDidChangeContent(workingCopy) {
        this.scheduleBackup(workingCopy);
    }
    scheduleBackup() { // 171
        this.workingCopyBackupService.backup() // 199
    }
}

// src\vs\workbench\services\workingCopy\common\workingCopyService.ts
class WorkingCopyService {
    registerWorkingCopy(workingCopy) { // 183
        workingCopy.onDidChangeContent(
            () => this._onDidChangeContent.fire(workingCopy)
        )
    }
}


// src\vs\workbench\services\untitled\common\untitledTextEditorModel.ts
class UntitledTextEditorModel {
    installModelListeners(model) {
        model.onDidChangeContent(
            e => this.onModelContentChanged(model, e)
        )
    }
    onModelContentChanged() {
        this._onDidChangeContent.fire();
    }
}

// entry point
async function test() {
    const browserMain = new BrowserMain()
    const fileService = new FileService()
    await browserMain.registerIndexedDBFileSystemProviders(fileService)
    let resource = {
        schema: Schemas.vscodeUserData
    }
    fileService.writeFile(resource)
}
test()
