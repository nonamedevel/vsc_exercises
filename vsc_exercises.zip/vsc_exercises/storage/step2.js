/*
    Add IndexedDB (a wrapper for indexedDB.open)
*/

// src\vs\base\browser\indexedDB.ts
class IndexedDB {
    static async create(name, version, stores) { // 25
        const database = await IndexedDB.openDatabase(name, version, stores)
		return new IndexedDB(database, name)
    }
    static async openDatabase(name, version, stores) { // 30
        return await IndexedDB.doOpenDatabase(name, version, stores)
    }
    static doOpenDatabase(name, version, stores) { // 55
        return new Promise((c, e) => {
            const request = indexedDB.open(name, version)
            request.onsuccess = () => {
				const db = request.result
                c(db)
            }
            request.onupgradeneeded = () => {
				const db = request.result
				for (const store of stores) {
                    db.createObjectStore(store)
				}
            }
        })
    }
	constructor(database) {
		this.database = database
	}
}

async function main() {
    const userDataStore = 'vscode-userdata-store'
    const indexedDB = await IndexedDB.create(
        'vscode-web-db', 
        3, 
        [userDataStore]
    )

    const tx = indexedDB.database.transaction(userDataStore, 'readwrite')
    const objectStore = tx.objectStore(userDataStore)
    const str = 'untitled:Untitled-1 {"typeId":""}\nabc'
    const uint8Array = new Uint8Array(str.length)
    for (let i = 0; i < str.length; i++) {
        uint8Array[i] = str.charCodeAt(i)
    }
    const key = '/User/Backups/-2ad0bbb/untitled/-7f9c1a2e'
    objectStore.put(uint8Array, key)
    tx.oncomplete = () => {
        console.log('Done')
    }
}

function test1() {
    const req = indexedDB.deleteDatabase('vscode-web-db')
    req.onsuccess = () => {
        main()
    }
}

function test() {
    main()
}

test()
