/*
    Starting point
    There is an untitled file with the text 'abc'.
    We save it into indexedDB.
*/

indexedDB.deleteDatabase('vscode-web-db').onsuccess = (event) => {
    const request = indexedDB.open('vscode-web-db')
    
    request.onsuccess = function() {
        const db = request.result
        const tx = db.transaction('vscode-userdata-store', 'readwrite')
        const objectStore = tx.objectStore('vscode-userdata-store')
        const str = 'untitled:Untitled-1 {"typeId":""}\nabc'
        const uint8Array = new Uint8Array(str.length)
        for (let i = 0; i < str.length; i++) {
            uint8Array[i] = str.charCodeAt(i)
        }
        const key = '/User/Backups/-2ad0bbb/untitled/-7f9c1a2e'
        objectStore.put(uint8Array, key)
        tx.oncomplete = () => {
            console.log('Data stored successfully!')
        }
    }
    
    request.onupgradeneeded = () => {
        const db = request.result
        db.createObjectStore('vscode-userdata-store')
    }
}
