

// src\vs\nls.ts
function localize(key, message) {
    return message
}

// src\vs\platform\extensionRecommendations\common\extensionRecommendations.ts
const RecommendationSource = {
	FILE: 1,
	WORKSPACE: 2,
	EXE: 3
}

// src\vs\workbench\browser\parts\notifications\notificationsActions.ts



// src\vs\workbench\contrib\extensions\browser\extensionRecommendationNotificationService.ts
class ExtensionRecommendationNotificationService {
    promptWorkspaceRecommendations() {
        this.promptRecommendationsNotification()
    }
    promptRecommendationsNotification() {
        const source = RecommendationSource.WORKSPACE
        let donotShowAgainLabel
        if (source === RecommendationSource.WORKSPACE) {
            donotShowAgainLabel = localize('donotShowAgain', 
                "Don't Show Again for this Repository")
        } else if (extensions.length > 1) {
            donotShowAgainLabel = localize('donotShowAgainExtension', 
                "Don't Show Again for these Extensions")
        } else {
            donotShowAgainLabel = localize('donotShowAgainExtensionSingle', 
                "Don't Show Again for this Extension")
        }
        this.showRecommendationsNotification()
    }
    showRecommendationsNotification() {
        const notificationContainer = document.createElement('div')
        notificationContainer.classList.add('notification_container')
        document.body.append(notificationContainer)
        
        const topRow = document.createElement('div')
        topRow.classList.add('top_row')
        notificationContainer.append(topRow)
        
        const infoIcon = document.createElement('div')
        infoIcon.classList.add('info_icon')
        infoIcon.textContent = 'i'
        topRow.append(infoIcon)
        
        const messageBox = document.createElement('div')
        messageBox.classList.add('message_box')
        messageBox.textContent = 'Do you want to install the recommended extensions from Microsoft, GitHub and others for this repository?'
        topRow.append(messageBox)
        
        const buttonBox = document.createElement('div')
        buttonBox.classList.add('button_box')
        topRow.append(buttonBox)
        
        const settingsButton = document.createElement('button')
        settingsButton.classList.add('settings')
        settingsButton.textContent = 'S'
        buttonBox.append(settingsButton)
        settingsButton.addEventListener('click', hideWidget)
        
        const closeButton = document.createElement('button')
        closeButton.classList.add('close')
        closeButton.textContent = 'C'
        buttonBox.append(closeButton)
        closeButton.addEventListener('click', hideWidget)
        
        const bottomRow = document.createElement('div')
        bottomRow.classList.add('bottom_row')
        notificationContainer.append(bottomRow)
        
        const installButton = document.createElement('button')
        installButton.classList.add('install')
        installButton.textContent = 'Install'
        bottomRow.append(installButton)
        installButton.addEventListener('click', hideWidget)
        
        const showRecommendationsButton = document.createElement('button')
        showRecommendationsButton.classList.add('show_recommendations')
        showRecommendationsButton.textContent = 'Show Recommendations'
        bottomRow.append(showRecommendationsButton)
        showRecommendationsButton.addEventListener('click', hideWidget)
        
        function hideWidget() {
            notificationContainer.style.display = 'none'
        }
    }
}

// src\vs\workbench\contrib\extensions\browser\extensionRecommendationsService.ts
class ExtensionRecommendationsService {
    constructor() {
        this.extensionRecommendationNotificationService = new ExtensionRecommendationNotificationService()
        this.activate()
    }
    activate() {
        this.promptWorkspaceRecommendations()
    }
    promptWorkspaceRecommendations() {
        this.extensionRecommendationNotificationService.promptWorkspaceRecommendations()
    }
}

// src\vs\platform\instantiation\common\descriptors.ts
class SyncDescriptor {
	constructor(ctor, staticArguments = [], supportsDelayedInstantiation = false) {
		this.ctor = ctor
		this.staticArguments = staticArguments
		this.supportsDelayedInstantiation = supportsDelayedInstantiation
	}
}

// src\vs\platform\instantiation\common\instantiation.ts
function createDecorator(serviceId) {
    const id = function() {}
    id.toString = () => serviceId
    return id
}

// src\vs\workbench\services\extensionRecommendations\common\extensionRecommendations.ts
const IExtensionRecommendationsService = createDecorator('extensionRecommendationsService')

// src\vs\platform\instantiation\common\extensions.ts
const _registry = []

const InstantiationType = {
	Eager: 0,
	Delayed: 1
}

function registerSingleton(id, ctorOrDescriptor, supportsDelayedInstantiation) {
	if (!(ctorOrDescriptor instanceof SyncDescriptor)) {
		ctorOrDescriptor = new SyncDescriptor(ctorOrDescriptor, [], Boolean(supportsDelayedInstantiation))
	}
	_registry.push([id, ctorOrDescriptor])
}

function getSingletonServiceDescriptors() {
	return _registry
}

// src\vs\workbench\contrib\extensions\browser\extensions.contribution.ts
registerSingleton(IExtensionRecommendationsService, ExtensionRecommendationsService, InstantiationType.Eager)


// src\vs\workbench\browser\workbench.ts
class Workbench {
    startup() {
        this.initServices()
    }
    initServices() {
        getSingletonServiceDescriptors()
    }
}


// src\vs\workbench\browser\web.main.ts
class BrowserMain {
    open() {
        const workbench = new Workbench()
        const instantiationService = workbench.startup()
    }
}

// src\vs\workbench\browser\web.factory.ts
function create() {
    new BrowserMain().open()
}


// src\vs\code\browser\workbench\workbench.ts
create()

// src\vs\workbench\electron-browser\desktop.main.ts
class DesktopMain {
    open() {
        const workbench = new Workbench()
        const instantiationService = workbench.startup()
    }
}


console.log(444)
// new ExtensionRecommendationsService()


/*

TODO: When is ExtensionRecommendationsService instantiated?

ExtensionWidget
    RecommendationWidget            src\vs\workbench\contrib\extensions\browser\extensionsWidgets.ts
    ExtensionHoverWidget            src\vs\workbench\contrib\extensions\browser\extensionsWidgets.ts
    ExtensionRecommendationWidget   src\vs\workbench\contrib\extensions\browser\extensionsWidgets.ts








*/

