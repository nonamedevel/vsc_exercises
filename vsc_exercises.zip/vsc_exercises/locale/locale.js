/*
    How can we change the UI language?

    workbench.action.configureLocale


    ILocaleService              src\vs\workbench\services\localization\common\locale.ts
        WebLocaleService        src\vs\workbench\services\localization\browser\localeService.ts
        NativeLocaleService     src\vs\workbench\services\localization\electron-browser\localeService.ts
*/

// src\vs\workbench\services\localization\browser\localeService.ts



// src\vs\workbench\contrib\localization\common\localizationsActions.ts
class ConfigureDisplayLanguageAction {
    static ID = 'workbench.action.configureLocale'
    run(accessor) {
        const localeService = accessor.get(ILocaleService)
        const selectedLanguage = ''
        localeService.setLocale(selectedLanguage)
    }
}



// src\vs\workbench\contrib\extensions\browser\extensionsWorkbenchService.ts
class ExtensionsWorkbenchService {
    setLanguage() {
        return this.localeService.setLocale({
            id: locale, 
            galleryExtension: extension.gallery, 
            extensionId: extension.identifier.id, 
            label: localizedLanguageName ?? extension.displayName 
        })
    }
}

