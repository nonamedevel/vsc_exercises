/*

This may also be interesting:
src\vs\workbench\browser\parts\titlebar\titlebarActions.ts



BaseActionViewItem                                      src\vs\base\browser\ui\actionbar\actionViewItems.ts
    CompositeBarActionViewItem                          src\vs\workbench\browser\parts\compositeBarActions.ts
        AbstractGlobalActivityActionViewItem            src\vs\workbench\browser\parts\globalCompositeBar.ts
            AccountsActivityActionViewItem              src\vs\workbench\browser\parts\globalCompositeBar.ts
                SimpleAccountActivityActionViewItem     src\vs\workbench\browser\parts\globalCompositeBar.ts
            GlobalActivityActionViewItem                src\vs\workbench\browser\parts\globalCompositeBar.ts
                SimpleGlobalActivityActionViewItem      src\vs\workbench\browser\parts\globalCompositeBar.ts




*/

// src\vs\workbench\common\activity.ts
const GLOBAL_ACTIVITY_ID = 'workbench.actions.manage'
const ACCOUNTS_ACTIVITY_ID = 'workbench.actions.accounts'


// src\vs\workbench\browser\parts\globalCompositeBar.ts
class GlobalCompositeBar {
    constructor() {
        this.element = document.createElement('div')
    }
    create(parent) {
		parent.appendChild(this.element)
	}
}
class AbstractGlobalActivityActionViewItem {

}
class AccountsActivityActionViewItem extends AbstractGlobalActivityActionViewItem {

}
class GlobalActivityActionViewItem extends AbstractGlobalActivityActionViewItem {

}


// entry point
const globalCompositeBar = new GlobalCompositeBar()
globalCompositeBar.create(document.body)
