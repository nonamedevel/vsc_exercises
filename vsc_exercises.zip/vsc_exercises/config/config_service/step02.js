/*
    What is the difference between these:
    ConfigurationService    src\vs\platform\configuration\common\configurationService.ts
    WorkspaceService        src\vs\workbench\services\configuration\browser\configurationService.ts

    What is the difference between these:
    Configuration           src\vs\platform\configuration\common\configurationModels.ts
    Configuration           src\vs\workbench\services\configuration\common\configurationModels.ts

    What is the difference between these:
    DefaultConfiguration    src\vs\platform\configuration\common\configurations.ts
    DefaultConfiguration    src\vs\workbench\services\configuration\browser\configuration.ts

*/



// src\vs\platform\configuration\common\configurationService.ts
class ConfigurationService {
    constructor() {
        this._onDidChangeConfiguration = new Emitter()
        this.onDidChangeConfiguration = this._onDidChangeConfiguration.event

        this.defaultConfiguration = new DefaultConfiguration()
        this.configuration = new Configuration(
            this.defaultConfiguration.configurationModel
        )
    }
    getValue(section) {
        return this.configuration.getValue(section)
    }
}

// entry point
function test() {
    const configurationService = new ConfigurationService()
    configurationService.getValue()
}

test()
