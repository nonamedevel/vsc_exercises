/*

ExtensionEditor.render
    ExtensionEditor.renderNavbar
        ExtensionEditor.onNavbarChange
            ExtensionEditor.open
                ExtensionEditor.openDetails
                    ExtensionEditor.renderAdditionalDetails
                        AdditionalDetailsWidget.constructor                         src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                            AdditionalDetailsWidget.render                          src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                                AdditionalDetailsWidget.renderMarketplaceInfo       src\vs\workbench\contrib\extensions\browser\extensionEditor.ts
                                    "Last Released"


*/



