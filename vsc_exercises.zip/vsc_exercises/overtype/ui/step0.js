/*

footer.statusbar
    div.left-items.items-container
    div.right-items.items-container
        div.statusbar-item
            a.statusbar-item-label

*/

const tooltip = 'Enable Insert Mode'
