/*
    Add InputModeImpl
*/

// src\vs\editor\common\inputMode.ts
class InputModeImpl { // Oji
    constructor() {
        this._inputMode = 'insert'
    }
    getInputMode() {
        return this._inputMode
    }
    setInputMode(inputMode) {
        this._inputMode = inputMode
    }
}
const InputMode = new InputModeImpl()

// entry point
const elem = document.createElement('div')
document.body.append(elem)

window.addEventListener('keydown', (e) => {
    if (e.key === 'Insert') {
        if (InputMode.getInputMode() === 'insert') {
            elem.textContent = 'OVT'
            InputMode.setInputMode('overtype')
        } else {
            elem.textContent = ''
            InputMode.setInputMode('insert')
        }
    }
})
