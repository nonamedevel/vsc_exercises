/*
    Starting point
*/

const elem = document.createElement('div')
document.body.append(elem)

window.addEventListener('keydown', () => {
    if (elem.textContent === '') {
        elem.textContent = 'OVT'
    } else {
        elem.textContent = ''
    }
})
