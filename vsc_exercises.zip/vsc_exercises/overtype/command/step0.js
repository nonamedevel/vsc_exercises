/*
    Overtype input mode

    What happens when a user presses the Insert button on the keyboard?

*/