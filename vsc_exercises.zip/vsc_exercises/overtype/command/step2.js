/*
    Add inputMode variable
    Check what key was pressed
*/

const elem = document.createElement('div')
document.body.append(elem)

let inputMode = 'insert'
window.addEventListener('keydown', (e) => {
    if (e.key === 'Insert') {
        if (inputMode === 'insert') {
            elem.textContent = 'OVT'
            inputMode = 'overtype'
        } else {
            elem.textContent = ''
            inputMode = 'insert'
        }
    }
})
