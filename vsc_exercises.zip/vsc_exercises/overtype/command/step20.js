
/*

    Order of execution:
    CommandService.executeCommand()
    InstantiationService.invokeFunction()

*/


// src\vs\base\common\event.ts
class Emitter { // 995
    get event() { // 1076
        this._event ??= (callback) => {
            this._listener = callback
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\editor\common\inputMode.ts
class InputModeImpl { // Oji
    constructor() {
        this._inputMode = 'insert'
        this._onDidChangeInputMode = new Emitter()
        this.onDidChangeInputMode = this._onDidChangeInputMode.event
    }
    getInputMode() {
        return this._inputMode
    }
    setInputMode(inputMode) {
        this._inputMode = inputMode
        this._onDidChangeInputMode.fire(this._inputMode)
    }
}
const InputMode = new InputModeImpl()

// src\vs\platform\commands\common\commands.ts
/*
    Simplified version. No LinkedList
*/
const CommandsRegistry = new class {
    constructor() {
        this._commands = new Map()
    }
    /*
        Can be called with object and command
        Who needs this flexibility?
    */
    registerCommand(idOrCommand) { // 74
        const { id } = idOrCommand
        this._commands.set(id, idOrCommand)
    }
    getCommand(id) {
        return this._commands.get(id)
    }
}

// src\vs\platform\actions\common\actions.ts
class Action2 { // 670
    constructor(desc) {
        this.desc = desc
    }
}
function registerAction2(ctor) { // 675
    const action = new ctor()
    const command = action.desc
    CommandsRegistry.registerCommand({
		id: command.id,
		handler: () => action.run(),
    })
}

// src\vs\workbench\contrib\codeEditor\browser\toggleOvertype.ts
class ToggleOvertypeInsertMode extends Action2 {
    constructor() {
        super({
            id: 'editor.action.toggleOvertypeInsertMode',
        })
    }
    run() {
		const oldInputMode = InputMode.getInputMode()
		const newInputMode = oldInputMode === 'insert' ? 'overtype' : 'insert'
		InputMode.setInputMode(newInputMode)
	}
}
registerAction2(ToggleOvertypeInsertMode)

// src\vs\base\browser\dom.ts
const { // 30
    onDidRegisterWindow
} = (function() {
    const onDidRegisterWindow = new Emitter()
    return {
        onDidRegisterWindow: onDidRegisterWindow.event,
    }
})();
function addDisposableListener(node, type, handler) { // 161
    node.addEventListener(type, handler)
}
const EventType = { // 1072
    KEY_DOWN: 'keydown',
}


// src\vs\base\common\event.ts
const Event = { // 41
    runAndSubscribe(event, handler, initial) { // 642
		handler(initial)
		return event(e => handler(e))
    }
} // 758

// src\vs\platform\instantiation\common\instantiationService.ts
class InstantiationService {
    invokeFunction(fn, ...args) { // 89
        fn(undefined, ...args)
    }
}

// src\vs\workbench\services\commands\common\commandService.ts
class CommandService {
    constructor(_instantiationService) {
        this._instantiationService = _instantiationService
    }
    executeCommand(id, ...args) { // 52
        this._tryExecuteCommand(id, args)
    }
    _tryExecuteCommand(id, args) { // 92
        const command = CommandsRegistry.getCommand(id)
        this._instantiationService.invokeFunction(
            command.handler,
            ...args
        )
    }
}

// src\vs\base\browser\window.ts
const mainWindow = window

class AbstractKeybindingService {
    constructor(_commandService) {
        this._commandService = _commandService
    }
    _dispatch(e, target) { // 224
        this._doDispatch(
            this.resolveKeyboardEvent(e), 
            target, 
            false
        );
    }
    resolveKeyboardEvent() {

    }
    _doDispatch() { // 282
        /*
            TODO: How is 'Insert' converted to commandId?
        */
        const resolveResult = {
            commandId: 'editor.action.toggleOvertypeInsertMode'
        }
        this._commandService.executeCommand(
            resolveResult.commandId
        )
    }
}

// src\vs\workbench\services\keybinding\browser\keybindingService.ts
class WorkbenchKeybindingService extends AbstractKeybindingService {
    constructor(_commandService) {
        super(_commandService)
        Event.runAndSubscribe(
            onDidRegisterWindow, 
            ({ window }) => this._registerKeyListeners(window), 
            { window: mainWindow }
        )
    }
    _registerKeyListeners() { // 273
        addDisposableListener(window, EventType.KEY_DOWN, (e) => {
            const keyEvent = {}
            this._dispatch(keyEvent, keyEvent.target);
        })
    }
}



// entry point
function test() {
    const instantiationService = new InstantiationService()
    const commandService = new CommandService(instantiationService)
    const workbenchKeybindingService = new WorkbenchKeybindingService(commandService)

    const elem = document.createElement('div')
    document.body.append(elem)

    InputMode.onDidChangeInputMode((inputMode) => {
        if (inputMode === 'overtype') {
            elem.textContent = 'OVT'
        } else {
            elem.textContent = ''
        }
    })
}
test()

