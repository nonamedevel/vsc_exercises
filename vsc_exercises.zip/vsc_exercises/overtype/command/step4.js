/*
    Add Emitter
*/

// src\vs\base\common\event.ts
class Emitter {
    get event() { // 1076
        this._event ??= (callback) => {
            this._listener = callback
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\editor\common\inputMode.ts
class InputModeImpl { // Oji
    constructor() {
        this._inputMode = 'insert'
        this._onDidChangeInputMode = new Emitter()
        this.onDidChangeInputMode = this._onDidChangeInputMode.event
    }
    getInputMode() {
        return this._inputMode
    }
    setInputMode(inputMode) {
        this._inputMode = inputMode
        this._onDidChangeInputMode.fire(this._inputMode)
    }
}
const InputMode = new InputModeImpl()

// entry point
window.addEventListener('keydown', (e) => {
    if (e.key === 'Insert') {
        const oldInputMode = InputMode.getInputMode()
        const newInputMode = oldInputMode === 'insert' ? 'overtype' : 'insert'
        InputMode.setInputMode(newInputMode)
    }
})

const elem = document.createElement('div')
document.body.append(elem)

InputMode.onDidChangeInputMode((inputMode) => {
    if (inputMode === 'overtype') {
        elem.textContent = 'OVT'
    } else {
        elem.textContent = ''
    }
})
