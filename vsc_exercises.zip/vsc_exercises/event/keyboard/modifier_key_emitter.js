
// src\vs\base\common\event.ts
const Event = { // 41
    runAndSubscribe(event, handler, initial) { // 642
		handler(initial)
		return event(e => handler(e))
    }
} // 758

// src\vs\base\browser\window.ts
const mainWindow = window

// src\vs\base\browser\dom.ts
const { // 30
    onDidRegisterWindow
} = (function() {
    const onDidRegisterWindow = new Emitter()
    return {
        onDidRegisterWindow: onDidRegisterWindow.event,
    }
})();

function addDisposableListener(node, type, handler) { // 161
    node.addEventListener(type, handler)
}

class ModifierKeyEmitter { // 1704
    constructor() {
        Event.runAndSubscribe(
            onDidRegisterWindow, 
            ({ window }) => this.registerListeners(window), 
            { window: mainWindow }
        )
    }
    registerListeners(window) {
        /*
            What is the point of creating EventType.KEY_DOWN,
            if we keep using 'keydown'?
        */
        addDisposableListener(window, 'keydown', e => {
            if (e.key === 'Insert') {
                // do something
            }
        })
    }
    static getInstance() {
		if (!ModifierKeyEmitter.instance) {
			ModifierKeyEmitter.instance = new ModifierKeyEmitter();
		}
		return ModifierKeyEmitter.instance;
	}
}


// entry point
function test() {
    ModifierKeyEmitter.getInstance()
}
test()
