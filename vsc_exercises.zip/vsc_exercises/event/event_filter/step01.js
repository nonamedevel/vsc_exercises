
/*
    What does Event.filter() do?
*/



// src\vs\base\common\event.ts
class Emitter {
    constructor(options) {
        this._options = options
    }
    get event() { // 1076
        this._event ??= (callback, thisArgs) => {
            if (thisArgs) {
				callback = callback.bind(thisArgs)
			}
            this._listener = callback
            this._options?.onWillAddFirstListener(this) // 1114
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\base\common\event.ts
const Event = (function() {
	function filter(event, filter) { // 161
		return snapshot(
            (listener, thisArgs = null) => {
                event(
                    e => filter(e) && listener.call(thisArgs, e), 
                    null
                )
            }
        )
	}
    function snapshot(event) { // 201
        const options = {
			onWillAddFirstListener() {
				event(emitter.fire, emitter);
			},
        }
		const emitter = new Emitter(options)
		return emitter.event
    }
    return {
        filter
    }
})()

// src\vs\platform\configuration\common\configuration.ts
function getConfigurationValue(config, settingPath) { // 317
	function accessSetting(config, path) {
		let current = config;
		for (const component of path) {
			if (typeof current !== 'object' || current === null) {
				return undefined;
			}
			current = current[component]
		}
		return current
	}

	const path = settingPath.split('.');
	const result = accessSetting(config, path);

	return typeof result === 'undefined' ? defaultValue : result
}

// src\vs\platform\configuration\common\configurationModels.ts
class ConfigurationModel { // 29
    static createEmptyModel() { // 31
        return new ConfigurationModel({}, [], [], undefined)
    }
    constructor(_contents) {
        this._contents = _contents
    }
	get contents() {
		return this._contents
	}
    getValue() { // 93
        // return getConfigurationValue(this.contents, section)
        return 444
    }
    merge() { // 156
        return new ConfigurationModel()
    }
} // 307
class BaseConfiguration { // 725
    constructor(_defaultConfiguration) {
        this._defaultConfiguration = _defaultConfiguration
    }
    getValue(section) { // 744
		const consolidateConfigurationModel = this.getConsolidatedConfigurationModel(section)
		return consolidateConfigurationModel.getValue(section)
    }
    getConsolidatedConfigurationModel() { // 990
        let configurationModel = this.getConsolidatedConfigurationModelForResource()
        return configurationModel
    }
    getConsolidatedConfigurationModelForResource() { // 1005
        let consolidateConfiguration = this.getWorkspaceConsolidatedConfiguration()
        return consolidateConfiguration
    }
	getWorkspaceConsolidatedConfiguration() { // 1022
		if (!this._workspaceConsolidatedConfiguration) {
			this._workspaceConsolidatedConfiguration = this._defaultConfiguration.merge(
                this.applicationConfiguration, 
                this.userConfiguration, 
                this._workspaceConfiguration, 
                this._memoryConfiguration
            )
		}
		return this._workspaceConsolidatedConfiguration
	}
} // 1153
class ConfigurationChangeEvent { // 1176
    constructor(value) {
        this.value = value
    }
    affectsConfiguration() {
        return true
    }
}

// src\vs\workbench\services\configuration\common\configurationModels.ts
class Configuration extends BaseConfiguration { // 99
    getValue(key) {
		return super.getValue(key)
	}
}

// src\vs\platform\configuration\common\configurations.ts
class BaseDefaultConfiguration {
	get configurationModel() {
		return this._configurationModel
	}
    constructor() {
        this._configurationModel = ConfigurationModel.createEmptyModel()
    }
}

// src\vs\workbench\services\configuration\browser\configuration.ts
class DefaultConfiguration extends BaseDefaultConfiguration {

}

// src\vs\workbench\services\configuration\browser\configurationService.ts
class WorkspaceService { // 63
    constructor() {
        this._onDidChangeConfiguration = new Emitter()
        this.onDidChangeConfiguration = this._onDidChangeConfiguration.event

        this.defaultConfiguration = new DefaultConfiguration()
        this._configuration = new Configuration(
            this.defaultConfiguration.configurationModel,
        )
    }
    getValue(section) { // 324
        return this._configuration.getValue(section)
    }
    updateValue(key, value) { // 334
        this.triggerConfigurationChange()
        this.writeConfigurationValue(key, value)
    }
    writeConfigurationValue(key, value) { // 1000

    }
    triggerConfigurationChange() { // 1114
        const configurationChangeEvent = new ConfigurationChangeEvent()
        this._onDidChangeConfiguration.fire(configurationChangeEvent)
    }
} // 1155

// src\vs\workbench\contrib\sash\browser\sash.ts
class SashSettingsController {
    constructor(configurationService) {
        this.configurationService = configurationService
        const onDidChangeSize = Event.filter(
            configurationService.onDidChangeConfiguration, 
            e => e.affectsConfiguration('workbench.sash.size')
        )
        // this.onDidChangeSize = this.onDidChangeSize.bind(this)
        onDidChangeSize(this.onDidChangeSize, this)
    }
    onDidChangeSize() { // 37
        const configuredSize = this.configurationService.getValue('workbench.sash.size')
        console.log(configuredSize)
    }
}

// ??
class EditorPane {
}

// src\vs\workbench\contrib\preferences\browser\settingsEditor2.ts
class SettingsEditor2 extends EditorPane { // 108
    onDidChangeSetting() { // 1187

    }
} // 2143

// entry point
function test() {
    const workspaceService = new WorkspaceService()
    const sashSettingsController = new SashSettingsController(workspaceService)

    const sashSizeInput = document.createElement('input')
    document.body.append(sashSizeInput)
    const okButton = document.createElement('button')
    okButton.textContent = 'Ok'
    document.body.append(okButton)
    okButton.onclick = () => {
        const key = 'workbench.sash.size'
        const value = sashSizeInput.value
        workspaceService.updateValue(key, value)
        sashSizeInput.value = ''
    }
}

test()
