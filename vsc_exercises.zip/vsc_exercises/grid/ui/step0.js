/*

+-------+-------+
|       | group |
| group +-------+
|       | group |
+-------+-------+

document.querySelectorAll('.grid-view-container')           1
document.querySelectorAll('.monaco-grid-view')              2
document.querySelectorAll('.monaco-grid-branch-node')       5

div.monaco-workbench
    div.monaco-grid-view
        div.monaco-grid-branch-node
            ...
                div.grid-view-container
                    div.monaco-grid-view
                        div.monaco-grid-branch-node


*/
