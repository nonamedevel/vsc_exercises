
// mock
class SplitView {
}

// src\vs\base\browser\ui\sash\sash.ts
const Orientation = {
	VERTICAL: 0,
	HORIZONTAL: 1,
}

// src\vs\base\browser\ui\grid\gridview.ts
class BranchNode { // 251
    constructor(
        orientation,
        layoutController,
        styles,
        splitviewProportionalLayout,
    ) {
        this.element = document.createElement('div') // 425
        this.element.classList.add('monaco-grid-branch-node')
        this.splitview = new SplitView(this.element)
    }
} // 751
class GridView { // 1039
    constructor() { // 1169
        this.element = document.createElement('div') // 1170
        this.element.classList.add('monaco-grid-view')
        this.root = new BranchNode( // 1174
            Orientation.VERTICAL, 
            this.layoutController, 
            this.styles, 
            this.proportionalLayout
        )
    }
} // 1837

// src\vs\workbench\browser\part.ts
class Part {
    create() {
        this.contentArea = this.createContentArea()
    }
}

// src\vs\workbench\browser\parts\editor\editorPart.ts
class GridWidgetView { // 51
    constructor() {
        this.element = document.createElement('div') // 53
        this.element.classList.add('grid-view-container')
    }
    set gridWidget(grid) {
        this.element.appendChild(grid.element)
    }
} // 89
class EditorPart extends Part { // 91
    constructor() {
        super()
        this.gridWidgetView = new GridWidgetView()
    }
    createContentArea(parent) { // 1004
        this.doCreateGridControl()
    }
    doCreateGridControl() { // 1175
        this.doSetGridWidget(new SerializableGrid()) // 1186
    }
    doSetGridWidget(gridWidget) { // 1271
        this.gridWidgetView.gridWidget = gridWidget
    }
} // 1505
class MainEditorPart extends EditorPart { // 1507
}

// src\vs\workbench\browser\parts\editor\editorParts.ts
class EditorParts {
    constructor() {
        this.mainPart = this.createMainEditorPart()
    }
    createMainEditorPart() {
        return new MainEditorPart()
    }
}

// src\vs\base\browser\ui\grid\grid.ts
class Grid { // 222
    constructor() {
        this.gridview = new GridView() // 308
    }
    get element() {
        return this.gridview.element
    }
} // 741
class SerializableGrid extends Grid { // 778
} // 861

// src\vs\workbench\browser\workbench.ts
class Workbench {
    constructor() {
        this.mainContainer = document.createElement('div')
        this.mainContainer.classList.add('monaco-workbench')
        this.parent = document.body
    }
    renderWorkbench() {
        const part = new MainEditorPart()
        part.create()
        this.parent.appendChild(this.mainContainer) // 362

        this.mainContainer.append(part.gridWidgetView.element) // hack

        // solution:
        // src\vs\workbench\browser\layout.ts
        this.mainContainer.prepend(workbenchGrid.element); // 1568
    }
}

// entry point
/*
    div.monaco-workbench
        div.monaco-grid-view
            div.monaco-grid-branch-node
*/
function test() {
    const workbench = new Workbench()
    workbench.renderWorkbench()

    // const gridView = new GridView()
    // monacoWorkbench.append(gridView.element)
}

/*
    div.grid-view-container
        div.monaco-grid-view
            div.monaco-grid-branch-node
*/
function test1() {
    const editorParts = new EditorParts()
    document.body.append(editorParts.mainPart.gridWidgetView.element)
    const gridView = new GridView()
    editorParts.mainPart.doSetGridWidget(gridView)
}

test()
