/*
    Looks like the div.monaco-workbench is created
    and then recreated (Why?!)
    This explains why the following proxy
    works in a simple HTML pages and
    does not work in VS Code
*/

function test1() {
    const container = document.createElement('div')
    container.classList.add('container')
    document.body.append(container)

    const elem = document.createElement('div')
    elem.classList.add('example')
    elem.textContent = 'Hello'
    // container.append(elem)
    container.appendChild(elem)
}

function test() {
    class Example {
        constructor() {
            this.mainContainer = document.createElement('div')
            this.mainContainer.classList.add('container')
            document.body.append(this.mainContainer)
        
            this.mainContainer = (function(container) {
                function _append(...param) {
                    console.log(param)
                    return container.append(...param)
                }
                function _appendChild(param) {
                    console.log(param)
                    return container._appendChild(param)
                }
                return new Proxy(container, {
                    get(target, prop) {
                        if (prop === 'append') {
                            console.log('append')
                            return _append.bind(target)
                        } else if (prop === 'appendChild') {
                            console.log('appendChild')
                            return _appendChild.bind(target)
                        } else {
                            try {
                                return target[prop].bind(target)
                            } catch(err) {
                                return target[prop]
                            }
                        }
                    }
                })
            })(this.mainContainer)
        
            const elem = document.createElement('div')
            elem.classList.add('example')
            elem.textContent = 'Hello!'
            this.mainContainer.append(elem)
            // this.mainContainer.appendChild(elem)
        }
    }
    const example = new Example()
}

/*
    We cannot simply overwrite 'window'
*/
function test1() {
    console.log(window)
    // window = 'hello'
    window = {a: 5}
    console.log(window)
}

function test1() {
    function func(window) {
        console.log(window)
        // window = 'hello'
        window = {a: 5}
        console.log(window)
    }
    func(window)
}

test()
