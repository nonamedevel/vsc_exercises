/*

Open Preview to the Side
Open Preview
Show Source


extensions\markdown-language-features\package.nls.json
extensions\markdown-language-features\package.json

*/


// extensions\markdown-language-features\src\preview\preview.ts
class MarkdownPreview {
    constructor() {
        this._webviewPanel.webview.onDidReceiveMessage((e) => {
            this._onDidClickPreview(e.line)
        })
    }
    _onDidClickPreview() {
        vscode.commands.executeCommand('markdown.showSource')
    }
}

// extensions\markdown-language-features\src\commands\showPreview.ts
class ShowPreviewCommand {
    constructor() {
        this.id = 'markdown.showPreview'
    }
    execute() {
        showPreview()
    }
}

// extensions\markdown-language-features\src\commands\showSource.ts
class ShowSourceCommand {
    constructor() {
        this.id = 'markdown.showSource'
    }
}
function showPreview() {
    vscode.commands.executeCommand('markdown.showSource')
}

// extensions\markdown-language-features\src\commandManager.ts
class CommandManager {
    register(command) {
        this._registerCommand(command.id, command.execute, command)
    }
    _registerCommand(id, impl, thisArg) {
        vscode.commands.registerCommand(id, impl, thisArg)
    }
}


// extensions\markdown-language-features\src\commands\index.ts
function registerMarkdownCommands(commandManager) {
    commandManager.register(new ShowPreviewCommand())
    commandManager.register(new ShowSourceCommand())
}

// extensions\markdown-language-features\src\extension.shared.ts
function activateShared() {
    const commandManager = new CommandManager()
    registerMarkdownCommands(commandManager)
}

// extensions\markdown-language-features\src\extension.ts
// extensions\markdown-language-features\src\extension.browser.ts
function activate() {
    activateShared()
}

// entry point
activate()
