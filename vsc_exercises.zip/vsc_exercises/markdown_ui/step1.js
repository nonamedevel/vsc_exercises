const navbar = document.createElement('navbar')
document.body.append(navbar)
const pageOne = document.createElement('button')
pageOne.textContent = 'page 1'
navbar.append(pageOne)
pageOne.addEventListener('click', onClick)
pageOne.style.backgroundColor = 'red'

const pageTwo = document.createElement('button')
pageTwo.textContent = 'page 2'
navbar.append(pageTwo)
pageTwo.addEventListener('click', onClick)


function onClick(){
    if (pageOne.style.backgroundColor === 'red'){
        pageOne.style.backgroundColor = ''
        pageTwo.style.backgroundColor = 'red'
    } else {
        pageOne.style.backgroundColor = 'red'
        pageTwo.style.backgroundColor = ''
    }
}