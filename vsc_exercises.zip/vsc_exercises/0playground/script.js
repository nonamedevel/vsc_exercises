const arrOrig = [5, 10, 15]
// const arrCopy = arrOrig.splice(0, arrOrig.length)
const arrCopy = [...arrOrig]
console.log(arrCopy)