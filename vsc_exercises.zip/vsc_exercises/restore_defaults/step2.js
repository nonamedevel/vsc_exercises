/*
cash
cache

*/

let tooltipElem // hack

// src\vs\platform\actions\common\actions.ts
let customizeLayoutAction

function registerAction2(ctor) {
    customizeLayoutAction = new ctor()
}

// src\vs\workbench\browser\actions\layoutActions.ts
registerAction2(class CustomizeLayoutAction {
    run(accessor) {
        const quickInputService = accessor.get()
        const quickPick = quickInputService.createQuickPick()
        
        const resetButton = {
            tooltip: 'Restore Defaults'
        }
        
        quickPick.buttons = [
            resetButton,
        ]
    }
})

// src\vs\platform\quickinput\browser\quickInputUtils.ts
function quickInputButtonToAction(button) {
    return {
        tooltip: button.tooltip
    }
}

// src\vs\platform\quickinput\browser\quickInput.ts
class QuickInput {
    constructor(ui) {
        this.ui = ui
    }
}

class QuickPick extends QuickInput {
    constructor(ui) {
        super(ui)
        this.onDidTriggerButtonEmitter = { fire() {} }
    }
    set buttons(buttons) {
        this._rightButtons = buttons
        this.update()
    }
    update() {
        const rightButtons = this._rightButtons
            .map((button, index) => quickInputButtonToAction(
                button,
                `id-${index}`,
                async () => this.onDidTriggerButtonEmitter.fire(button)
            ))
        this.ui.rightActionBar.push(rightButtons)
        this.tooltipElem = tooltipElem // hack
        this.tooltipElem.textContent = rightButtons[0].tooltip
    }
}

// src\vs\base\browser\ui\actionbar\actionViewItems.ts
class BaseActionViewItem {
    render(container) {
        container.addEventListener('click', function() {
            console.log('click')
        })
    }
}

class ActionViewItem extends BaseActionViewItem {
    render(container) {
        super.render(container)
    }
}

// src\vs\base\browser\ui\actionbar\actionbar.ts
class ActionBar {
    constructor(container) {
        this.domNode = document.createElement('div')
        this.actionsList = document.createElement('ul')
		this.domNode.appendChild(this.actionsList)
		container.appendChild(this.domNode)
    }
    push(actions) {
        actions.forEach((action) => {
            const actionViewItemElement = document.createElement('li')
            const item = new ActionViewItem()
            item.render(actionViewItemElement)
            this.actionsList.appendChild(actionViewItemElement)
        })
    }
}


// src\vs\platform\quickinput\browser\quickInputController.ts
class QuickInputController {
    constructor(options) {
        this._container = options.container
    }
    createQuickPick() {
        const ui = this.getUI()
        return new QuickPick(ui)
    }
    getUI() {
        const container = document.createElement('div')
        this._container.append(container)

        const titleBar = document.createElement('div')
        container.append(titleBar)
        const rightActionBar = new ActionBar(titleBar)

        const restoreDefaultsButton = document.createElement('button')
        document.body.append(restoreDefaultsButton)
        restoreDefaultsButton.textContent = 'Arrow'
        restoreDefaultsButton.addEventListener('click', function() {
            console.log('click')
        })
        restoreDefaultsButton.addEventListener('mouseenter', () => {
            this.tooltipElem.style.display = ''
        })
        restoreDefaultsButton.addEventListener('mouseleave', () => {
            this.tooltipElem.style.display = 'none'
        })

        this.tooltipElem = document.createElement('div')
        tooltipElem = this.tooltipElem // hack
        this.tooltipElem.style.display = 'none'
        this.tooltipElem.classList.add('tooltip')
        document.body.append(this.tooltipElem)

        this.ui = {
            rightActionBar
        }
        return this.ui
    }
}

// src\vs\platform\quickinput\browser\quickInputService.ts
class QuickInputService {
    constructor(layoutService) {
        this.layoutService = layoutService
        this._controller = null
    }
	get controller() {
		if (!this._controller) {
			this._controller = this.createController()
		}

		return this._controller
	}
    createController() {
        const controller = new QuickInputController({
            container: this.layoutService.activeContainer
        })
        return controller
    }
    createQuickPick() {
        return this.controller.createQuickPick()
    }
}


// src\vs\platform\instantiation\common\descriptors.ts
class SyncDescriptor {
	constructor(ctor, staticArguments = [], supportsDelayedInstantiation = false) {
		this.ctor = ctor
		this.staticArguments = staticArguments
		this.supportsDelayedInstantiation = supportsDelayedInstantiation
	}
}


// src\vs\platform\instantiation\common\extensions.ts
const _registry = []
const InstantiationType = {
	Eager: 0,
	Delayed: 1
}
function registerSingleton(id, ctorOrDescriptor, supportsDelayedInstantiation) {
	if (!(ctorOrDescriptor instanceof SyncDescriptor)) {
		ctorOrDescriptor = new SyncDescriptor(ctorOrDescriptor, [], Boolean(supportsDelayedInstantiation))
	}
	_registry.push([id, ctorOrDescriptor])
}


// src\vs\platform\instantiation\common\instantiation.ts
function createDecorator(serviceId) {
	const id = function () {}
	id.toString = () => serviceId
	return id
}


// src\vs\platform\quickinput\common\quickInput.ts
const IQuickInputService = createDecorator('quickInputService')


// src\vs\workbench\services\quickinput\browser\quickInputService.ts
customizeLayoutAction.run({
    get() {
        let layoutService = {activeContainer: document.body}
        const quickInputService = new QuickInputService(layoutService)
        return quickInputService
    }
})

registerSingleton(IQuickInputService, QuickInputService, InstantiationType.Delayed)


