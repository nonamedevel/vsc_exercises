/*

Main
sw.js
webWorkerExtensionHostIframe.html
ExtensionHostWorker
ExtensionHostWorker -> anycode.server.browser.js

***** When a file is opened *****

editorWorkerService
LanguageDetectionWorker

***** When a directory is opened *****

LocalFileSearchWorker
TextMateWorker
ExtensionHostWorker -> jsonServerMain.js




*/