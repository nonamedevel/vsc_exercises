/*

Property '_number' may not exist on type 'Example'. Did you mean 'number'?ts(2568)
quick_fix.js(10, 9): 'number' is declared here.

*/

class Example {
    constructor() {
        // this._number = 123
    }
    get number() {
        return this._number
    }
    // set number(number) {
    //     this._number = number
    // }
}

const example = new Example()
console.log(example.number)

// example.number = 456
// console.log(example.number)
