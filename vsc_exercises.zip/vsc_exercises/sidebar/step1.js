/*

workbench.action.toggleActivityBarVisibility

workbench.action.focusActivityBar

workbench.action.activityBarLocation.default
workbench.action.activityBarLocation.hide
workbench.action.activityBarLocation.bottom
workbench.action.activityBarLocation.top

Disposable                                          src\vs\base\common\lifecycle.ts
    Themable                                        src\vs\platform\theme\common\themeService.ts
        Component                                   src\vs\workbench\common\component.ts
            Part                                    src\vs\workbench\browser\part.ts
                CompositePart                       src\vs\workbench\browser\parts\compositePart.ts
                    AbstractPaneCompositePart       src\vs\workbench\browser\parts\paneCompositePart.ts
                        SidebarPart                 src\vs\workbench\browser\parts\sidebar\sidebarPart.ts



Workbench.renderWorkbench                       src\vs\workbench\browser\workbench.ts
    AbstractPaneCompositePart.create            src\vs\workbench\browser\parts\paneCompositePart.ts
        Part.create                             src\vs\workbench\browser\part.ts
            CompositePart.createContentArea     src\vs\workbench\browser\parts\compositePart.ts



*/


// src\vs\workbench\browser\actions\layoutActions.ts


// src\vs\workbench\browser\parts\sidebar\sidebarPart.ts



// src\vs\base\browser\dom.ts

