/*

src\vs\editor\common\cursor\cursor.ts


src\vs\editor\browser\controller\editContext\native\nativeEditContext.ts


native-edit-context


editor.action.moveLinesDownAction
*/

// src\vs\editor\common\cursor\cursorMoveCommands.ts
class CursorMoveCommands {
    simpleMove() { // 273
        this._moveLeft()
    }
    _moveLeft() { // 434

    }
}


// src\vs\base\common\keyCodes.ts
const KeyCode = {
    LeftArrow: 15
}

// src\vs\editor\browser\coreCommands.ts
class CoreEditorCommand { // 38
	runEditorCommand(accessor, editor, args) {
		const viewModel = editor._getViewModel()
		this.runCoreEditorCommand(viewModel, args || {})
	}
}
class CursorMoveBasedCommand extends CoreEditorCommand { // 659
    constructor() {
        super()
    }
    runCoreEditorCommand() {
        CursorMoveCommands.simpleMove(
            viewModel, 
            viewModel.getCursorStates(), 
            args.direction, 
            args.select, 
            args.value, 
            args.unit
        )
    }
}
const CursorLeft = registerEditorCommand(new CursorMoveBasedCommand({ // 690
    kbOpts: {
        primary: KeyCode.LeftArrow,
    }
}))

// src\vs\editor\browser\editorExtensions.ts
class EditorContributionRegistry {
	static INSTANCE = new EditorContributionRegistry()
    registerEditorCommand() {
        
    }
}

function registerEditorCommand(editorCommand) {
	EditorContributionRegistry.INSTANCE.registerEditorCommand(editorCommand)
	return editorCommand
}

class EditorCommand {
    runCommand(accessor, args) {
		return EditorCommand.runEditorCommand(
            accessor, 
            args, 
            this.precondition, 
            (accessor, editor, args) => this.runEditorCommand(accessor, editor, args)
        )
	}
}

class Command {
    register() {
    	CommandsRegistry.registerCommand({
			id: this.id,
			handler: (accessor, args) => this.runCommand(accessor, args),
			metadata: this.metadata
		})
    }
}


// src\vs\base\browser\dom.ts
class DomListener {
    constructor(node, type, handler) {
        node.addEventListener(type, handler)
    }
}
function addDisposableListener(node, type, handler, useCaptureOrOptions) {
    return new DomListener(node, type, handler, useCaptureOrOptions)
}
const EventType = {
    KEY_DOWN: 'keydown',
}

// src\vs\platform\keybinding\common\abstractKeybindingService.ts
class AbstractKeybindingService {
	_dispatch(e, target) {
		return this._doDispatch(this.resolveKeyboardEvent(e), target, false)
	}
}

// src\vs\workbench\services\keybinding\browser\keybindingService.ts
class WorkbenchKeybindingService extends AbstractKeybindingService {
    _registerKeyListeners() {
        addDisposableListener(window, EventType.KEY_DOWN, (e) => {
            this._dispatch(keyEvent, keyEvent.target)
        })
    }
}


const workbenchKeybindingService = new WorkbenchKeybindingService()
workbenchKeybindingService._registerKeyListeners()
