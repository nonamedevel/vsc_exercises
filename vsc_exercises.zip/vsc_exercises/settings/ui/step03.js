/*
    Task: Learn all about the Settings widget


div.editor-group-container                      EditorGroupView
    div.title                                   EditorGroupView
    div.editor-container                        EditorGroupView
        div.editor-instance                     EditorPanes
            div.settings-editor                 SettingsEditor2
                div.settings-header             SettingsEditor2
                div.settings-body               SettingsEditor2

div.settings-body                               SettingsEditor2
    div.monaco-split-view2
        div.monaco-scrollable
            div.split-view-container
                div.split-view-view (left)
                div.split-view-view (right)

div.split-view-view (right)
    div.settings-tree-container
        div.monaco-list
            div.monaco-scrollable-element
                div.monaco-list-rows
                    div.monaco-list-row
                        div.monaco-tl-row
                            div.monaco-tl-contents
                                div.setting-item-contents   AbstractSettingRenderer

div.setting-item-contents
    div.setting-item-title                      AbstractSettingRenderer
        div.setting-item-cat-label-container    AbstractSettingRenderer
            span.setting-item-category          AbstractSettingRenderer     "Workbench > Sash:"
            span.setting-item-label             AbstractSettingRenderer     "Size"
    div.setting-item-description                AbstractSettingRenderer
    div.setting-item-value
    div.setting-toolbar-container               AbstractSettingRenderer



*/


// src\vs\workbench\contrib\preferences\browser\settingsTree.ts
class AbstractSettingRenderer { // 825
    renderCommonTemplate(tree, _container) { // 895
        const container = document.createElement('div') // 901
        // container.classList.add('')
        _container.append(container)
    }
} // 1100

// src\vs\workbench\browser\parts\editor\editorPane.ts
class EditorPane {
	create(parent) {
		this.createEditor(parent)
	}
}

// src\vs\workbench\contrib\preferences\browser\settingsEditor2.ts
class SettingsEditor2 extends EditorPane { // 108
    createEditor(parent) { // 451
        this.rootElement = document.createElement('div') // 453
        this.rootElement.classList.add('settings-editor')
        parent.append(this.rootElement)
        this.createHeader(this.rootElement) // 455
        this.createBody(this.rootElement)
    }
    createBody(parent) { // 946
        this.bodyContainer = document.createElement('div') // 947
        this.bodyContainer.classList.add('settings-body')
        parent.append(this.bodyContainer)
    }
} // 2143

// src\vs\workbench\browser\parts\editor\editorPanes.ts
class EditorPanes {
    doCreateEditorPane() { // 360
        const editorPane = this.doInstantiateEditorPane()
        const editorPaneContainer = document.createElement('div')
        editorPaneContainer.classList.add('editor-instance')
        editorPane.create(editorPaneContainer)
    }
    doInstantiateEditorPane() {
        return new SettingsEditor2()
    }
}

// entry point
function test() {
    const editorPanes = new EditorPanes()
}

test()
