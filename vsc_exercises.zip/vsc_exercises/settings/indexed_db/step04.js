/*
    Scenario: User changes the setting value via UI,
    it is then written to IndexedDB

    "/User/settings.json"

*/