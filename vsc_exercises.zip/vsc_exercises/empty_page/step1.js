/*

Empty:
Show All Commands
Open File
Open Folder
Open Recent
Open Chat


When a folder is opened:
Show All Commands
Go to File
Open Chat
Open Settings
Find in Files

*/

// src\vs\base\common\platform.ts
const OperatingSystem = {
	Windows: 1,
	Macintosh: 2,
	Linux: 3
}

let _isMacintosh, _isIOS, _isWindows
const OS = (() => {
    if (_isMacintosh || _isIOS) {
        return OperatingSystem.Macintosh
    } else if (_isWindows) {
        return OperatingSystem.Windows
    } else {
        return OperatingSystem.Linux
    }
})()

const defaultKeybindingLabelStyles = {}

const keybindings = {
    'Show All Commands': 'Ctrl + Shift + P',
    'Open File': 'Ctrl + O',
    'Open Folder': 'Ctrl + K Ctrl + O',
    'Open Recent': 'Ctrl + R',
    'Open Chat': 'Ctrl + Alt + I',
}

class KeybindingService {
    lookupKeybinding(id) {
        return keybindings[id]
    }
}

class KeybindingLabel {
    set() {}
}

function append(parent, child) {
    parent.append(child)
    return child
}

function $(tagName) {
    return document.createElement(tagName)
}

// src\vs\workbench\browser\parts\editor\editorGroupWatermark.ts
class EditorGroupWatermark {
    constructor() {
        this.keybindingService = new KeybindingService()
    }
    render() {
        const entries = [
            {id: 'Show All Commands'},
            {id: 'Open File'},
            {id: 'Open Folder'},
            {id: 'Open Recent'},
            {id: 'Open Chat'},
        ]
        const box = document.querySelector('.box')
        for (const entry of entries) {
            const keys = this.keybindingService.lookupKeybinding(entry.id)
            const dl = append(box, $('dl'))
            const dt = append(dl, $('dt'))
            dt.textContent = entry.text

            const dd = append(dl, $('dd'))

            const label = new KeybindingLabel(
                dd, 
                OS, 
                { 
                    renderUnboundKeybindings: true,
                    ...defaultKeybindingLabelStyles 
                }
            )
            label.set(keys)
        }
    }
}

const editorGroupWatermark = new EditorGroupWatermark()
editorGroupWatermark.render()
