/*

Additional Views

*/

function localize() {}

class ThemeIcon {
    static asClassNameArray() {
    }
}

class Codicon {}


// src\vs\workbench\browser\parts\compositeBarActions.ts
class CompositeBarAction { // 82
    constructor(item) {

    }
}

class CompositeOverflowActivityAction extends CompositeBarAction { // 449
	constructor(showMenu) {
		super({
			id: 'additionalComposites.action',
			name: localize('additionalViews', "Additional Views"),
			classNames: ThemeIcon.asClassNameArray(Codicon.more)
		})
        this.showMenu = showMenu
	}
	async run() {
		this.showMenu()
	}
}

class CompositeBarActionViewItem { // 155
    render(container) { // 232
        this.container = container
        this.container.setAttribute('role', 'button')
    }
}

class CompositeOverflowActivityActionViewItem extends CompositeBarActionViewItem { // 466

}

// src\vs\workbench\browser\parts\compositeBar.ts
class CompositeBar { // 234
    updateCompositeSwitcher() {
        this.compositeOverflowAction = new CompositeOverflowActivityAction(() => { // 619
            console.log('showMenu()')
        })
        this.compositeOverflowActionViewItem = new CompositeOverflowActivityActionViewItem()
    }
}


// custom entry point
const compositeBar = new CompositeBar()
compositeBar.updateCompositeSwitcher()
compositeBar.compositeOverflowAction.run()

const actionsContainer = document.createElement('ul')
actionsContainer.classList.add('actions-container')
document.body.append(actionsContainer)

const listItem = document.createElement('li')
actionsContainer.append(listItem)

compositeBar.compositeOverflowActionViewItem.render(listItem)
