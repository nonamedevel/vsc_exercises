/*

There is a zoom widget in the status bar in electron,
which is not present in the browser.
How is it implemented?

*/