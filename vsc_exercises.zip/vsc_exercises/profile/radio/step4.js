/*
    Add event listeners
*/

// src\vs\base\browser\dom.ts
function addDisposableListener(node, type, handler) { // 161
    node.addEventListener(type, handler)
}
const EventType = { // 1072
    CLICK: 'click',
}

// src\vs\base\common\event.ts
class Emitter { // 995
    get event() { // 1076
        this._event ??= (callback) => {
            this._listener = callback
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\base\browser\ui\button\button.ts
class Button {
	_onDidClick = new Emitter()
    // why use a getter here?
	get onDidClick() { return this._onDidClick.event }
    constructor(container) {
		this._element = document.createElement('a') // 113
		this._element.classList.add('monaco-button')
        container.append(this._element) // 144
		addDisposableListener(this._element, EventType.CLICK, e => { // 149
            this._onDidClick.fire(e)
        })
    }
    getContentElements(content) { // 198
        const elements = []
        const segment = content
        const span = document.createElement('span')
        span.textContent = segment
        elements.push(span)
        return elements
        this._element.append(span)
    }
	get element() { // 233
		return this._element
	}
    set label(value) { // 237
        this._element.classList.add('monaco-text-button')
        const labelElement = this._element
        labelElement.textContent = ''
        labelElement.append(...this.getContentElements(value))
    }
}

// src\vs\base\browser\ui\radio\radio.ts
class Radio {
	_onDidSelect = new Emitter()
	onDidSelect = this._onDidSelect.event
    constructor(opts) {
        this.buttons = new Map()
        this.domNode = document.createElement('div')
        this.domNode.classList.add('monaco-custom-radio')
		this.setItems(opts.items)
    }
    setItems(items) { // 64
        this.items = items
        this.activeItem = this.items.find(item => item.isActive) ?? this.items[0]
        for (let index = 0; index < this.items.length; index++) {
            const item = this.items[index]
            const button = new Button(this.domNode)
			button.onDidClick(() => {
				if (this.activeItem !== item) {
					this.activeItem = item
					this.updateButtons()
					this._onDidSelect.fire(index)
				}
			})
            this.buttons.set(button, { item })
        }
        this.updateButtons()
    }
    updateButtons() { // 103
		for (const [button, { item }] of this.buttons) {
            button.element.classList.toggle('active', item === this.activeItem)
			button.label = item.text
		}
    }
}

// entry point
function test() {    
    const radio1 = new Radio({ items: [] })
    document.body.append(radio1.domNode)
    radio1.setItems([
        {text: 'Default'},
        {text: 'Hello', isActive: true},
    ])
    radio1.onDidSelect(() => {
        console.log('radio1')
    })

    const radio2 = new Radio({ items: [] })
    document.body.append(radio2.domNode)
    radio2.setItems([
        {text: 'Default'},
        {text: 'Hello'},
    ])
    radio2.onDidSelect(() => {
        console.log('radio2')
    })

    const radio3 = new Radio({ items: [] })
    document.body.append(radio3.domNode)
    radio3.setItems([
        {text: '1'},
        {text: '2'},
        {text: '3'},
        {text: '4'},
        {text: '5'},
    ])
    radio3.onDidSelect(() => {
        console.log('radio3')
    })

    document.body.style.display = 'flex'
    document.body.style.flexDirection = 'column'
    document.body.style.gap = '5px'
}

test()
