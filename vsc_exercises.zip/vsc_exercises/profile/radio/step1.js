/*
    Starting point

    div.monaco-custom-radio
        a.monaco-button
            span
        a.monaco-button
            span
*/

const customRadio = document.createElement('div')
customRadio.classList.add('monaco-custom-radio')
document.body.append(customRadio)
const arr = ['Default', 'Hello']
for (const item of arr) {
    const button = document.createElement('a')
    button.classList.add('monaco-button')
    customRadio.append(button)
    const span = document.createElement('span')
    button.append(span)
    span.textContent = item
}
customRadio.lastElementChild.classList.add('active')
