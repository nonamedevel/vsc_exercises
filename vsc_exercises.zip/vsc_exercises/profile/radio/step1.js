/*
    Starting point

    div.monaco-custom-radio
        a.monaco-button
            span
        a.monaco-button
            span
*/

const customRadio = document.createElement('div')
customRadio.classList.add('monaco-custom-radio')
document.body.append(customRadio)
const items = ['Default', 'Hello']
for (const item of items) {
    const button = document.createElement('a')
    button.classList.add('monaco-button')
    button.classList.add('monaco-text-button')
    customRadio.append(button)
    const span = document.createElement('span')
    button.append(span)
    span.textContent = item
}
customRadio.firstElementChild.classList.add('active')
// customRadio.lastElementChild.classList.add('active')
