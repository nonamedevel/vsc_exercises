/*
    How to set the textContent of a button
*/

// src\vs\base\browser\ui\button\button.ts
class Button {
    constructor(container) {
		this._element = document.createElement('a')
		this._element.classList.add('monaco-button')
        container.append(this._element)
    }
    getContentElements(content) { // 198
        const elements = []
        const segment = content
        const span = document.createElement('span')
        span.textContent = segment
        elements.push(span)
        return elements
    }
	get element() { // 233
		return this._element
	}
    set label(value) { // 237
        this._element.classList.add('monaco-text-button')
        const labelElement = this._element
        labelElement.textContent = ''
        labelElement.append(...this.getContentElements(value))
    }
}

// src\vs\base\browser\ui\radio\radio.ts
class Radio {
    constructor(opts) {
        this.buttons = new Map()
        this.domNode = document.createElement('div')
        this.domNode.classList.add('monaco-custom-radio')
		this.setItems(opts.items)
    }
    setItems(items) { // 64
        this.items = items
        this.activeItem = this.items.find(item => item.isActive) ?? this.items[0]
        for (let index = 0; index < this.items.length; index++) {
            const item = this.items[index]
            const button = new Button(this.domNode)
            this.buttons.set(button, { item })
        }
        this.updateButtons()
    }
    updateButtons() { // 103
		for (const [button, { item }] of this.buttons) {
            button.element.classList.toggle('active', item === this.activeItem)
			button.label = item.text
		}
    }
}

// entry point
function test() {    
    const radio1 = new Radio({ items: [] })
    document.body.append(radio1.domNode)
    radio1.setItems([
        {text: 'Default'},
        {text: 'Hello', isActive: true},
    ])
    
    const radio2 = new Radio({ items: [] })
    document.body.append(radio2.domNode)
    radio2.setItems([
        {text: 'Default'},
        {text: 'Hello'},
    ])
}

test()
