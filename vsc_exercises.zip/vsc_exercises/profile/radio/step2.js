/*
    Add Radio and Button
*/

// src\vs\base\browser\ui\button\button.ts
class Button {
    constructor(container, item) {
        const button = document.createElement('a')
        button.classList.add('monaco-button')
        button.classList.add('monaco-text-button')
        container.append(button)
        const span = document.createElement('span')
        button.append(span)
        span.textContent = item
    }
}

// src\vs\base\browser\ui\radio\radio.ts
class Radio {
    constructor(opts) {
        this.domNode = document.createElement('div')
        this.domNode.classList.add('monaco-custom-radio')
		this.setItems(opts.items)
    }
    setItems(items) {
        this.items = items
        for (let index = 0; index < this.items.length; index++) {
            new Button(this.domNode, this.items[index])
        }
    }
}

// entry point
function test() {
    const items = ['Default', 'Hello']
    
    const radio1 = new Radio({items})
    document.body.append(radio1.domNode)
    radio1.domNode.firstElementChild.classList.add('active')
    
    const radio2 = new Radio({items})
    document.body.append(radio2.domNode)
    radio2.domNode.lastElementChild.classList.add('active')
}

test()
