/*
    Add UserDataProfilesEditorInput
*/

// placeholders
const ThemeIcon = {
    asClassName() {}
}
const Codicon = {}
function localize(){}

// src\vs\base\common\actions.ts
class Action { // 60
    constructor(id, label, cssClass, enabled, actionCallback) {
        this._actionCallback = actionCallback
    }
    run() {
        this._actionCallback()
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class UserDataProfileElement{ //408
    constructor(_profile, titleButtons, actions){
		this.actions = actions
    }
}

class UserDataProfilesEditorModel { // 879
    static INSTANCE
	static getInstance(instantiationService) {
		if (!UserDataProfilesEditorModel.INSTANCE) {
			UserDataProfilesEditorModel.INSTANCE = new UserDataProfilesEditorModel();
		}
		return UserDataProfilesEditorModel.INSTANCE;
	}
    constructor() {
        this.dialogService = {
            confirm(obj) {
                console.log(obj.message)
            }
        }
    }
    createProfileElement() { // 969
		const deleteAction = new Action(
			'userDataProfile.delete',
			localize('delete', "Delete"),
			ThemeIcon.asClassName(Codicon.trash), // do we really need it?
			true,
			() => this.removeProfile()
		)
        const secondaryActions = [] //1014
        secondaryActions.push(deleteAction) //1019

		const profileElement = new UserDataProfileElement(
			undefined,
			undefined,
			[undefined, secondaryActions]
        )
        return [profileElement];
    }
    removeProfile() { // 1302
        this.dialogService.confirm({
            message: 'Are you sure you want to delete the profile?'
        })
    }
} // 1317

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditor.ts
class UserDataProfilesEditorInput {
    constructor() {
        this.model = UserDataProfilesEditorModel.getInstance()
    }
}


// entry point
function test() {
    const input = new UserDataProfilesEditorInput()
    const model = input.model
    const [profileElement] = model.createProfileElement()
    const action = profileElement.actions[1][0]
    action.run()
}

test()
