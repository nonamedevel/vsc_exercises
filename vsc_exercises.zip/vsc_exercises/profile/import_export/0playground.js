
/*
    Simple closure
*/
function test() {
    function func(num1) {
        return function(num2) {
            return num1 + num2
        }
    }
    const add5 = func(5)
    console.log(add5(10))
    console.log(add5(15))

    const add100 = func(100)
    console.log(add100(10))
    console.log(add100(15))
}

function test() {
    function func() {
        const inputElem = document.createElement('input')
        document.body.append(inputElem)
        inputElem.addEventListener('input', () => {
            const num2 = Number(inputElem.value)
            console.log(num1 + num2)
        })
        let num1
        return {
            setValue(value) {
                num1 = value
            }
        }
    }
    const {setValue} = func()
    setValue(5)
}

test()
