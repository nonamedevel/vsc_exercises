/*



*/

// placeholders
const ThemeIcon = {
    asClassName() {}
}
const Codicon = {}
function localize(p1, p2){
    return p2
}
function registerAction2(ctor) {
    const action = new ctor() // hack
    action.run()
}

// src\vs\workbench\services\userDataProfile\browser\userDataProfileImportExportService.ts
class UserDataProfileImportExportService { // 66
    constructor() {
        this.dialogService = {
            prompt(obj) {
                const dialogContainer = document.createElement('div')
                document.body.append(dialogContainer)

                const messageElem = document.createElement('div')
                messageElem.textContent = obj.message
                dialogContainer.append(messageElem)

                const okButton = document.createElement('button')
                okButton.textContent = 'Ok'
                dialogContainer.append(okButton)
                okButton.addEventListener('click', () => {
                    dialogContainer.remove()
                })
            }
        }
    }
    exportProfile(profile) { // 222
        const userDataProfilesExportState = new UserDataProfileExportState(profile)
        this.doExportProfile(userDataProfilesExportState)
    }
    doExportProfile(userDataProfilesExportState) { // 256
        const profile = userDataProfilesExportState.getProfileToExport()
        const message = `Profile '${profile.name}' was exported successfully.`
        this.dialogService.prompt({ message })
    }
} // 493
class UserDataProfileImportExportState { // 548
    getProfileTemplate(name) {
        return { name }
    }
} // 656
class UserDataProfileExportState extends UserDataProfileImportExportState { // 658
    constructor(profile) {
        super()
        this.profile = profile
    }
    getProfileToExport() {
        let name = this.profile.name
        return super.getProfileTemplate(name)
    }
} // 784

// src\vs\base\common\actions.ts
class Action {
    constructor(id, label, cssClass, enabled, actionCallback) {
        const exportButton = document.createElement('button')
        document.body.append(exportButton)
        exportButton.textContent = label
        exportButton.addEventListener('click', () => {
            exportButton.remove()
            document.body.append(localButton)
        })

        const localButton = document.createElement('button')
        localButton.textContent = 'Local'
        localButton.addEventListener('click', () => {
            localButton.remove()
            document.body.append(saveButton)
        })

        const saveButton = document.createElement('button')
        saveButton.textContent = 'Save'
        saveButton.addEventListener('click', () => {
            saveButton.remove()
            actionCallback()
        })
    }
}

// src\vs\platform\userDataProfile\common\userDataProfile.ts
class UserDataProfilesService { // 190
    constructor() {

    }
    get profilesObject() { // 238
        const profiles = []
        profiles.push({
            name: 'Example5'
        })
        // profiles.push(toUserDataProfile(
        //     basename(storedProfile.location), 
        //     storedProfile.name, 
        //     storedProfile.location, 
        //     this.profilesCacheHome, 
        //     { 
        //         icon: storedProfile.icon, 
        //         useDefaultFlags: storedProfile.useDefaultFlags 
        //     },
        //     defaultProfile
        // ))
        this._profilesObject = { profiles }
        return this._profilesObject
    }
    get profiles() { // 201
        return [
            ...this.profilesObject.profiles
        ]
    }
    updateProfile(profile) { // 357

    }
} // 636

// src\vs\platform\userDataProfile\browser\userDataProfile.ts
class BrowserUserDataProfilesService extends UserDataProfilesService {
    constructor() {
        super()
    }
}

// src\vs\workbench\services\userDataProfile\browser\userDataProfileManagement.ts
class UserDataProfileManagementService {
    constructor(userDataProfilesService) {
        this.userDataProfilesService = userDataProfilesService
    }
    updateProfile(profile) {
        const updatedProfile = this.userDataProfilesService.updateProfile(profile)
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class AbstractUserDataProfileElement { // 98
    constructor() {
        this.userDataProfileManagementService = new UserDataProfileManagementService()
    }
    set name(name) { // 155
        this.save() // How so?
    }
	save() { // 361
		this.doSave()
	}
    saveProfile(profile) { // 381
        this.userDataProfileManagementService.updateProfile(profile)
    }
} // 406
class UserDataProfileElement extends AbstractUserDataProfileElement { // 408
	doSave() {
		this.saveProfile(this.profile)
	}
} // 550
class UserDataProfilesEditorModel { // 879
    constructor(userDataProfileService, userDataProfilesService) {
        this.userDataProfileImportExportService = new UserDataProfileImportExportService()
        const profile = userDataProfilesService.profiles[0]
        this.createProfileElement(profile)
    }
    createProfileElement(profile) { // 969
		const exportAction = new Action(
			'userDataProfile.export',
			localize('export', "Export..."),
			ThemeIcon.asClassName(Codicon.export),
			true,
			() => this.userDataProfileImportExportService.exportProfile(profile)
		)
    }
} // 1317

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditor.ts
class ProfileNameRenderer { // 913
    renderTemplate() { // 924
        const profileElement = {
            root: new UserDataProfileElement()
        }
        const nameInput = document.createElement('input')
        nameInput.style.display = 'block'
        nameInput.placeholder = 'Profile Name'
        document.body.append(nameInput)
        nameInput.addEventListener('input', () => {
            profileElement.root.name = nameInput.value
        })
    }
} // 1013
class UserDataProfilesEditorInput {
    constructor() {
        const userDataProfilesService = new BrowserUserDataProfilesService()
        this.model = new UserDataProfilesEditorModel(undefined, userDataProfilesService)
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfile.ts
class UserDataProfilesWorkbenchContribution {
    registerManageProfilesAction() {
        registerAction2(class ManageProfilesAction {
            run() {
                new UserDataProfilesEditorInput()
            }
        })
    }
}

// entry point
function test() {
    const profileNameRenderer = new ProfileNameRenderer()
    profileNameRenderer.renderTemplate()

    const contrib = new UserDataProfilesWorkbenchContribution()
    contrib.registerManageProfilesAction()
}

test()
