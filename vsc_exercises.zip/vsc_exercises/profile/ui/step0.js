/*

Profiles Editor HTML Hierarchy:

div.editor-group-container
    div.title
    div.editor-container


div.editor-container
    div.editor-instance
        div.profiles-editor
            div.monaco-split-view2
                div.sash-container
                div.monaco-scrollable-element


div.monaco-scrollable-element
    div.split-view-container
        div.split-view-view
        div.split-view-view


div.split-view-view
    div.sidebar-view
        div.sidebar-container
            div.new-profile-button
                div.monaco-button-dropdown
            div.profiles-list


div.split-view-view
    div.contents-view
        div.contents-container
            div.profile-header
            div.profile-body
                div.profile-tree

div.profile-tree
    div.monaco-list
        div.monaco-scrollable-element
            div.monaco-list-rows
                div.monaco-list-row     // Name
                div.monaco-list-row     // Icon
                div.monaco-list-row     // Use for New Windows
                div.monaco-list-row     // Contents
                div.monaco-list-row     // Folders & Workspaces


div.monaco-list-row     // Name, Icon...
    div.monaco-tl-row
        div.monaco-tl-contents
            div.profile-row-container

div.profile-row-container       // Name, Icon...
    div.profile-label-element
    div.profile-description-element
    div.profile-content-tree-header
    div.profile-content-tree

div.profile-content-tree
    div.monaco-list
        div.monaco-scrollable-element
            div.monaco-list-rows
                div.monaco-list-row     // Settings
                div.monaco-list-row     // Keyboard Shortcuts
                div.monaco-list-row     // Tasks
                div.monaco-list-row     // MCP Servers
                div.monaco-list-row     // Snippets
                div.monaco-list-row     // Extensions


div.monaco-list-row     // Settings, Keyboard Shortcuts...
    div.monaco-tl-row
        div.monaco-tl-contents
            div.profile-tree-item-container
                div.profile-resource-type-label
                div.profile-resource-options-container
                div.profile-resource-actions-container


div.profile-resource-options-container
    div.monaco-custom-radio
        a.monaco-button
            span
        a.monaco-button
            span


div.profile-resource-actions-container
    div.monaco-toolbar
        div.monaco-action-bar
            ul.actions-container
                li.action-item
                    a.action-label


div.profile-row-container       // Folders & Workspaces
    div.profile-label-element
    div.profile-description-element
    div.profile-associations-table
    div.profile-workspaces-button-container
        div.monaco-button       // Add Folder


*/