/*

AbstractProfileResourceTreeRenderer
    ProfilePropertyRenderer
        ProfileNameRenderer
        ProfileIconRenderer
        UseForCurrentWindowPropertyRenderer
        UseAsDefaultProfileRenderer
        CopyFromProfileRenderer
        ContentsProfileRenderer
        ProfileWorkspacesRenderer
    ExistingProfileResourceTreeRenderer
    NewProfileResourceTreeRenderer
    ProfileResourceChildTreeItemRenderer


*/

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditor.ts


