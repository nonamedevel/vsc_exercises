/*
    Add UserDataProfileElement
*/

// placeholders
const ThemeIcon = {
    asClassName() {}
}
const Codicon = {}
function localize(){}

// src\vs\base\common\actions.ts
class Action { // 60
    constructor(id, label, cssClass, enabled, actionCallback) {
        this._actionCallback = actionCallback
    }
    run() {
        this._actionCallback()
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class UserDataProfileElement{ //408
    constructor(_profile, titleButtons, actions){
		this.actions = actions
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class UserDataProfilesEditorModel{ // 879
    constructor() {
        this.dialogService = {
            confirm(obj) {
                console.log(obj.message)
            }
        }
    }
    createProfileElement(){
        const deleteAction = new Action(
            'userDataProfile.delete',
            localize('delete', "Delete"),
            ThemeIcon.asClassName(Codicon.trash), // do we really need it?
            true,
            () => this.removeProfile()
        )
        const secondaryActions = [] //1014
        secondaryActions.push(deleteAction) //1019

		const profileElement = new UserDataProfileElement(
			undefined,
			undefined,
			[undefined, secondaryActions]
        )
        return [profileElement];
    }
    removeProfile(){
        this.dialogService.confirm({
            message: 'Are you sure you want to delete the profile?'
        })
    }
}

// entry point
function test(){
    const model = new UserDataProfilesEditorModel()
    const [profileElement] = model.createProfileElement()
    const action = profileElement.actions[1][0]
    action.run()
}

test()