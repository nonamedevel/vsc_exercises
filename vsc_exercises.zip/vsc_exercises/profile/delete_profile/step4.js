/*
    Move deleteAction 
    into UserDataProfilesEditorModel.createProfileElement()
*/

// placeholders
const ThemeIcon = {
    asClassName() {}
}
const Codicon = {}
function localize(){}

// src\vs\base\common\actions.ts
class Action { // 60
    constructor(id, label, cssClass, enabled, actionCallback) {
        this._actionCallback = actionCallback
    }
    run() {
        this._actionCallback()
    }
}

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class UserDataProfilesEditorModel{ // 879
    constructor() {
        this.dialogService = {
            confirm(obj) {
                console.log(obj.message)
            }
        }
    }
    createProfileElement(){
        const deleteAction = new Action(
            'userDataProfile.delete',
            localize('delete', "Delete"),
            ThemeIcon.asClassName(Codicon.trash), // do we really need it?
            true,
            () => this.removeProfile()
        )
        deleteAction.run()
    }
    removeProfile(){
        this.dialogService.confirm({
            message: 'Are you sure you want to delete the profile?'
        })
    }
}

// entry point
function test(){
    const model = new UserDataProfilesEditorModel()
    model.createProfileElement()
}

test()