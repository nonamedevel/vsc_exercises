/*
    Starting point
*/

console.log('Are you sure you want to delete the profile?')
