/*
    Scenario: User opens the Profile editor, 
        then clicks on a profile,
        then clicks on 'More Actions...',
        then clicks on 'Delete',
        then a dialog appears with the text
            'Are you sure you want to delete the profile'.
    How is this implemented?

    We use a simple console.log() instead of an actual dialog.
    The dialog functionality is studied separately.
*/
