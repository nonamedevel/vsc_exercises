/*
    Add UserDataProfilesEditorModel
*/

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditorModel.ts
class UserDataProfilesEditorModel { // 879
    constructor() {
        this.dialogService = {
            confirm(obj) {
                console.log(obj.message)
            }
        }
    }
    removeProfile(){
        this.dialogService.confirm({
            message: 'Are you sure you want to delete the profile?'
        })
    }
}

// entry point
function test(){
    const model = new UserDataProfilesEditorModel()
    model.removeProfile()
}

test()