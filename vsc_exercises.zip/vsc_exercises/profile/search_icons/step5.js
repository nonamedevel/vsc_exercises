/*
    Our own simple version of Icon select box
*/

