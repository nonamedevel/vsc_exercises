/*
    Scenario: User clicks on the icon button in the profiles editor,
    a widget with a set of 84 icons is shown as a result.
    User can select an icon from that set by clicking on it.
*/

// placeholders
function localize(p1, p2) {
    return p2
}

// ???
class InputBox {

}

// src\vs\base\browser\ui\icons\iconSelectBox.ts
class IconSelectBox {
    constructor() {
        this.domNode = document.createElement('div') // 57
        this.domNode.classList.add('icon-select-box')
        this.create()
    }
    create() {
        const iconSelectBoxContainer = document.createElement('div') // 64
        iconSelectBoxContainer.classList.add('icon-select-box-container')
        this.domNode.append(iconSelectBoxContainer)

        const iconSelectInputContainer = document.createElement('div')
        iconSelectInputContainer.classList.add('icon-select-input-container')
        iconSelectBoxContainer.append(iconSelectInputContainer)

		this.inputBox = new InputBox(iconSelectInputContainer, undefined, {
			placeholder: localize('iconSelect.placeholder', "Search icons"),
		})
    }
}

// entry point
function test() {
    const iconSelectBox = new IconSelectBox()
    document.body.append(iconSelectBox.domNode)
}
test()
