/*
    Scenario: User clicks on the icon button in the profiles editor,
    a widget with a set of 84 (12 x 7) icons is shown as a result.
    User can select an icon from that set by clicking on it.

div.monaco-workbench
  div.monaco-grid-view
  div.context-view
    div.workbench-hover-container
      div.monaco-hover
        div.monaco-scrollable-element
          div.monaco-hover-content
            div.hover-row
              div.hover-contents
                div.icon-select-box


div.icon-select-box
  div.icon-select-box-container
    div.icon-select-input-container
      div.monaco-inputbox
        div.ibwrapper
          input
    div.monaco-srollable-element
      div.icon-select-icons-container
        div.icon-container
          div.codicon
        div.icon-container
          div.codicon
        ...

*/

// placeholders
function localize(p1, p2) {
    return p2
}
const Codicon = {}

// src\vs\workbench\services\userDataProfile\common\userDataProfileIcons.ts
const ICONS1 = [
	Codicon.settingsGear,
	Codicon.vm,
	Codicon.server,
	Codicon.recordKeys,
	Codicon.deviceMobile,
	Codicon.watch,
	Codicon.vr,
	Codicon.piano,
	Codicon.ruby,
	Codicon.code,
	Codicon.coffee,
	Codicon.snake,
	Codicon.project,
	Codicon.window,
	Codicon.library,
	Codicon.extensions,
	Codicon.terminal,
	Codicon.terminalDebian,
	Codicon.terminalLinux,
	Codicon.terminalUbuntu,
	Codicon.beaker,
	Codicon.package,
	Codicon.cloud,
	Codicon.book,
	Codicon.globe,
	Codicon.database,
	Codicon.notebook,
	Codicon.robot,
	Codicon.game,
	Codicon.chip,
	Codicon.music,
	Codicon.remoteExplorer,
	Codicon.github,
	Codicon.azure,
	Codicon.vscode,
	Codicon.copilot,
	Codicon.gift,
	Codicon.send,
	Codicon.bookmark,
	Codicon.briefcase,
	Codicon.megaphone,
	Codicon.comment,
	Codicon.telescope,
	Codicon.creditCard,
	Codicon.map,
	Codicon.deviceCameraVideo,
	Codicon.unmute,
	Codicon.law,
	Codicon.graphLine,
	Codicon.heart,
	Codicon.home,
	Codicon.inbox,
	Codicon.mortarBoard,
	Codicon.rocket,
	Codicon.magnet,
	Codicon.lock,
	Codicon.milestone,
	Codicon.tag,
	Codicon.pulse,
	Codicon.radioTower,
	Codicon.smiley,
	Codicon.zap,
	Codicon.squirrel,
	Codicon.symbolColor,
	Codicon.mail,
	Codicon.key,
	Codicon.pieChart,
	Codicon.organization,
	Codicon.preview,
	Codicon.wand,
	Codicon.starEmpty,
	Codicon.lightbulb,
	Codicon.symbolRuler,
	Codicon.dashboard,
	Codicon.calendar,
	Codicon.shield,
	Codicon.verified,
	Codicon.debug,
	Codicon.flame,
	Codicon.compass,
	Codicon.paintcan,
	Codicon.archive,
	Codicon.mic,
	Codicon.jersey,
];

const ICONS = [
    ['settings-gear', 0xeb51],
    ['vm', 0xea7a],
    ['server', 0xeb50],
    ['record-keys', 0xea65],
    ['device-mobile', 0xeadb],
    ['watch', 0xeb7c],
    ['vr', 0xec18],
    ['piano', 0xec1a],
    ['ruby', 0xeb48],
    ['code', 0xeac4],
    ['coffee', 0xec15],
    ['snake', 0xec16],
    ['project', 0xeb30],
    ['window', 0xeb7f],
    ['library', 0xeb9c],
    ['extensions', 0xeae6],
    ['terminal', 0xea85],
    ['terminal-debian', 0xebc5],
    ['terminal-linux', 0xebc6],
    ['terminal-ubuntu', 0xebc9],
    ['beaker', 0xea79],
    ['package', 0xeb29],
    ['cloud', 0xebaa],
    ['book', 0xeaa4],
    ['globe', 0xeb01],
    ['database', 0xeace],
    ['notebook', 0xebaf],
    ['robot', 0xec20],
    ['game', 0xec17],
    ['chip', 0xec19],
    ['music', 0xec1b],
    ['remote-explorer', 0xeb39],
    ['github', 0xea84],
    ['azure', 0xebd8],
    ['vscode', 0xec29],
    ['copilot', 0xec1e],
    ['gift', 0xeaf9],
    ['send', 0xec0f],
    ['bookmark', 0xeaa5],
    ['briefcase', 0xeaac],
    ['megaphone', 0xeb1e],
    ['comment', 0xea6b],
    ['telescope', 0xeb68],
    ['credit-card', 0xeac9],
    ['map', 0xec05],
    ['device-camera-video', 0xead9],
    ['unmute', 0xeb75],
    ['law', 0xeb12],
    ['graph-line', 0xebe2],
    ['heart', 0xeb05],
    ['home', 0xeb06],
    ['inbox', 0xeb09],
    ['mortar-board', 0xeb21],
    ['rocket', 0xeb44],
    ['magnet', 0xebae],
    ['lock', 0xea75],
    ['milestone', 0xeb20],
    ['tag', 0xea66],
    ['pulse', 0xeb31],
    ['radio-tower', 0xeb34],
    ['smiley', 0xeb54],
    ['zap', 0xea86],
    ['squirrel', 0xeb58],
    ['symbol-color', 0xeb5c],
    ['mail', 0xeb1c],
    ['key', 0xeb11],
    ['pie-chart', 0xebe4],
    ['organization', 0xea7e],
    ['preview', 0xeb2f],
    ['wand', 0xebcf],
    ['star-empty', 0xea6a],
    ['lightbulb', 0xea61],
    ['symbol-ruler', 0xea96],
    ['dashboard', 0xeacd],
    ['calendar', 0xeab0],
    ['shield', 0xeb53],
    ['verified', 0xeb77],
    ['debug', 0xead8],
    ['flame', 0xeaf2],
    ['compass', 0xebd5],
    ['paintcan', 0xeb2a],
    ['archive', 0xea98],
    ['mic', 0xec12],
    ['jersey', 0xeb0e],
]


// src\vs\base\browser\ui\widget.ts
class Widget {
    oninput(domNode, listener) {
        domNode.addEventListener('input', listener)
    }
}

// src\vs\base\browser\ui\inputbox\inputBox.ts
class InputBox extends Widget {
    constructor(container, contextViewProvider, options) {
        super()
        this.input = document.createElement('input') // 145
        this.input.placeholder = options.placeholder
        container.append(this.input) // 145
        this.oninput(this.input, () => this.onValueChange()) // 199
    }
    onValueChange() {
        console.log(this.input.value)
    }
}

// src\vs\base\browser\ui\icons\iconSelectBox.ts
class IconSelectBox {
    constructor(options) {
        this.options = options
        this.domNode = document.createElement('div') // 57
        this.domNode.classList.add('icon-select-box')
        this.create()
    }
    create() { // 61
        const iconSelectBoxContainer = document.createElement('div') // 64
        iconSelectBoxContainer.classList.add('icon-select-box-container')
        this.domNode.append(iconSelectBoxContainer)

        const iconSelectInputContainer = document.createElement('div')
        iconSelectInputContainer.classList.add('icon-select-input-container')
        iconSelectBoxContainer.append(iconSelectInputContainer)

		this.inputBox = new InputBox(iconSelectInputContainer, undefined, {
			placeholder: localize('iconSelect.placeholder', "Search icons"),
		})

        const iconsContainer = document.createElement('div') // 74
        iconsContainer.classList.add('icon-select-icons-container')
        iconSelectBoxContainer.append(iconsContainer)

        this.renderIcons(this.options.icons, [], iconsContainer) // 88
    }
    renderIcons(icons, matches, container) { // 115
        for (let index = 0; index < icons.length; index++) {
            const icon = icons[index]
            const iconContainer = document.createElement('div')
            iconContainer.classList.add('icon-container')
            container.append(iconContainer)

            const elem = document.createElement('div') // 131
			elem.classList.add(`codicon-${icon[0]}`)
            iconContainer.append(elem)
        }
    }
}

// src\vs\workbench\services\userDataProfile\browser\iconSelectBox.ts
class WorkbenchIconSelectBox extends IconSelectBox {
    constructor(options) {
        super(options)
    }
}

// entry point
function test() {
    const iconSelectBox = new WorkbenchIconSelectBox({ 
        icons: ICONS,
    })
    document.body.append(iconSelectBox.domNode)

	const style = document.createElement('style')
	let arr = []
	for (const icon of ICONS) {
		arr.push(`.codicon-${icon[0]}:before {
			font-family: 'codicon';
			content: '\\${icon[1].toString(16)}';
		}`)
	}
	style.innerHTML = arr.join('\n')
	document.head.appendChild(style)
}
test()
