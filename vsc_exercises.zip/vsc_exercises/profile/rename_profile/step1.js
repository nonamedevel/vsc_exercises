/*
    Starting point
*/
console.log('Step 1')

let profileName = 'Example1'

const nameElem = document.createElement('div')
nameElem.textContent = profileName
document.body.append(nameElem)

const nameInput = document.createElement('input')
nameInput.placeholder = 'Profile Name'
nameInput.value = profileName
document.body.append(nameInput)
nameInput.addEventListener('input', () => {
    if (nameInput.value.length === 0) {
        return
    }
    profileName = nameInput.value
    nameElem.textContent = profileName
})
