/*
    Scenario: User opens the profiles editor and changes
    the name of an existing profile via the profile name input,
    the profile title element content is updated as a result
*/
