/*
    Add ProfileWidget and InputBox
*/
console.log('Step 2')

// src\vs\workbench\contrib\userDataProfile\browser\userDataProfilesEditor.ts
class ProfileWidget { // 509
    constructor() {
        const title = document.createElement('div')
        title.classList.add('profile-title-container')
        document.body.append(title)
        this.profileTitle = document.createElement('div')
        title.append(this.profileTitle)
    }
    render(profileElement) { // 622
		this.profileTitle.textContent = profileElement.name
    }
} // 704

// src\vs\base\browser\ui\inputbox\inputBox.ts
class InputBox {
    constructor() {
        this.input = document.createElement('input') // 145
        document.body.append(this.input) // 145
        this.input.addEventListener('input', () => this.onValueChange()) // 199
    }
    onValueChange() {
        if (this.input.value.length === 0) {
            return
        }
        profileWidget.render({
            name: this.input.value
        })
    }
}

// entry point
let profileName = 'Example1'

const profileWidget = new ProfileWidget()
profileWidget.render({
    name: profileName
})

const inputBox = new InputBox()
inputBox.input.placeholder = 'Profile Name'
inputBox.input.value = profileName
