class DeferredPromise {
    constructor() {
		this.p = new Promise((c, e) => {
			this.completeCallback = c;
			this.errorCallback = e;
		});
    }
}

function test() {
    const deferred = new DeferredPromise()
    console.log(deferred.p)
    setTimeout(() => {
        // deferred.completeCallback(123)
        deferred.errorCallback('error')
    }, 2000)
    deferred.p.then((result) => {
        console.log(result)
    }).catch((err) => {
        console.log(err)
    })
}

test()
