// src\vs\base\common\async.ts
class DeferredPromise { // 1731
	static fromPromise(promise) {
		const deferred = new DeferredPromise();
		deferred.settleWith(promise);
		return deferred;
	}
	get isRejected() {
		return this.outcome?.outcome === DeferredOutcome.Rejected;
	}
	get isResolved() {
		return this.outcome?.outcome === DeferredOutcome.Resolved;
	}
	get isSettled() {
		return !!this.outcome;
	}
	get value() {
		return this.outcome?.outcome === DeferredOutcome.Resolved ? this.outcome?.value : undefined;
	}
	constructor() {
		this.p = new Promise((c, e) => {
			this.completeCallback = c;
			this.errorCallback = e;
		});
	}
	complete(value) {
		if (this.isSettled) {
			return Promise.resolve();
		}

		return new Promise(resolve => {
			this.completeCallback(value);
			this.outcome = { outcome: DeferredOutcome.Resolved, value };
			resolve();
		});
	}
	error(err) {
		if (this.isSettled) {
			return Promise.resolve();
		}

		return new Promise(resolve => {
			this.errorCallback(err);
			this.outcome = { outcome: DeferredOutcome.Rejected, value: err };
			resolve();
		});
	}
	settleWith(promise) {
		return promise.then(
			value => this.complete(value),
			error => this.error(error)
		);
	}
	cancel() {
		return this.error(new CancellationError());
	}
}
