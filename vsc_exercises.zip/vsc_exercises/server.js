const http = require('http')
const fs = require('fs')

const server = http.createServer((req, res) => {
    console.log(req.url)
    if (req.url === '/') {
        fs.readFile('index.html', (err, data) => {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url.endsWith('sw.js')) {
        fs.readFile(req.url.slice(1), (err, data) => {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'application/javascript',
                'Service-Worker-Allowed': '/',
            })
            res.end(data)
        })
    } else if (req.url.endsWith('.js')) {
        fs.readFile(req.url.slice(1), (err, data) => {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'application/javascript'
            })
            res.end(data)
        })
    } else if (req.url.endsWith('.txt')) {
        fs.readFile(req.url.slice(1), (err, data) => {
            if (err) throw err
            res.writeHead(200, {
                'Content-Type': 'text/plain'
            })
            res.end(data)
        })
    } else {
        res.end()
    }
})

server.listen(8000)
