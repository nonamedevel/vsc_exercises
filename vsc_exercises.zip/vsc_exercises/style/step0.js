/*
    Adding stylesheets dynamically

1   style                               head  0  empty  src\vs\platform\quickinput\browser\quickInputController.ts ?
2   style.contributedColorTheme         head  0         src\vs\workbench\services\themes\browser\workbenchThemeService.ts
3   style.contributedFileIconTheme      head  0         src\vs\workbench\services\themes\browser\fileIconThemeData.ts
4   style.contributedProductIconTheme   head  0  empty
5   style#codiconStyles                 head  0         src\vs\workbench\services\themes\browser\workbenchThemeService.ts
6   style                               head  0  empty
7   style                               head  0  empty
8   style.vscode-tokens-styles          head  0         src\vs\workbench\services\textMate\browser\textMateTokenizationFeatureImpl.ts
9   style                               head  0         src\vs\workbench\contrib\terminal\browser\terminalService.ts
10  style                               head  0         src\vs\workbench\contrib\sash\browser\sash.ts
11  style                               head  0         src\vs\workbench\contrib\scm\browser\quickDiffDecorator.ts
12  style                               head  0  empty
13  style                               body  0         src\vs\base\browser\ui\breadcrumbs\breadcrumbsWidget.ts
14  style                               body  0         src\vs\workbench\browser\parts\statusbar\statusbarPart.ts

15  style                               body  0         src\vs\platform\quickinput\browser\quickInputController.ts
16  style                               body  0         ???
17  style                               body  0         ???
18  style                               body  0         ???
19  style                               body  0         ???

??                                                      src\vs\base\browser\ui\menu\menu.ts
??                                                      src\vs\base\browser\ui\table\tableWidget.ts


There are 2 ways to add a <style> element:
1   createStyleSheet()
2   ???

startup             14
quick input          5
profiles editor      8
extensions tab       3
keyboard shortcuts   3
settings             2-5



*/



