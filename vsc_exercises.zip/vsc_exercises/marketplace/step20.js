/*
    Add request(), AbstractRequestService and BrowserRequestService
*/
console.log('Step 20')

// src\vs\base\parts\request\common\requestImpl.ts
async function request(options) {
    const res = await fetch(options.url)
    return res
}

// src\vs\platform\request\common\request.ts
class AbstractRequestService {
    async logAndRequest(options, request) {
        const result = await request()
        return result
    }
}

// src\vs\workbench\services\request\browser\requestService.ts
class BrowserRequestService extends AbstractRequestService {
    async request(options) { // 36
        const context = await this.logAndRequest(
            options, 
            () => request(options)
        )
        return context
    }
}

async function test() {
    const extensionsControlUrl = 'https://main.vscode-cdn.net/extensions/marketplace.json'
    const requestService = new BrowserRequestService()
    const context = await requestService.request({
        type: 'GET',
        url: extensionsControlUrl,
    })
    const result = await context.json()
    console.log(result)
}

test()
