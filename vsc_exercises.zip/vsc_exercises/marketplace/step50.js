/*
    Add ExtensionManagementServerService, Extensions and ExtensionsWorkbenchService
*/
console.log('Step 50')

// src\vs\base\parts\request\common\requestImpl.ts
async function request(options) {
    const res = await fetch(options.url)
    return res
}

// src\vs\platform\request\common\request.ts
class AbstractRequestService {
    async logAndRequest(options, request) {
        const result = await request()
        return result
    }
}

// src\vs\workbench\services\request\browser\requestService.ts
class BrowserRequestService extends AbstractRequestService {
    async request(options) { // 36
        const context = await this.logAndRequest(
            options, 
            () => request(options)
        )
        return context
    }
}

// src\vs\platform\extensionManagement\common\extensionGalleryService.ts
class AbstractExtensionGalleryService {
    constructor() {
        this.requestService = new BrowserRequestService()
    }
    async getExtensionsControlManifest() { // 1799
        this.extensionsControlUrl = 'https://main.vscode-cdn.net/extensions/marketplace.json'
        const context = await this.requestService.request({
			type: 'GET',
			url: this.extensionsControlUrl,
        })
        const result = await context.json() // 1820
        return result
    }
}

// src\vs\workbench\services\extensionManagement\common\extensionGalleryService.ts
class WorkbenchExtensionGalleryService extends AbstractExtensionGalleryService {
}

// src\vs\platform\extensionManagement\common\abstractExtensionManagementService.ts
class AbstractExtensionManagementService {
    constructor() {
        this.galleryService = new WorkbenchExtensionGalleryService()
    }
    getExtensionsControlManifest() { // 244
        this.extensionsControlManifest = this.updateControlCache() // 248
        return this.extensionsControlManifest
    }
    async updateControlCache() { // 965
        return await this.galleryService.getExtensionsControlManifest()
    }
}

// src\vs\workbench\services\extensionManagement\common\webExtensionManagementService.ts
class WebExtensionManagementService extends AbstractExtensionManagementService {
}

// src\vs\workbench\services\extensionManagement\common\extensionManagementServerService.ts
class ExtensionManagementServerService {
    constructor() {
        const extensionManagementService = new WebExtensionManagementService()
        this.webExtensionManagementServer = {
            extensionManagementService,
        }
    }
}

// src\vs\workbench\contrib\extensions\browser\extensionsWorkbenchService.ts
class Extensions { // 592
    constructor(server) {
        this.server = server
    }
    async queryInstalled() { // 665
        await this.fetchInstalledExtensions()
    }
    async fetchInstalledExtensions() { // 812
        const extensionsControlManifest = await this.server.extensionManagementService.getExtensionsControlManifest()
        console.log(extensionsControlManifest)
    }
} // 971
class ExtensionsWorkbenchService { // 973
    constructor() {
        const extensionManagementServerService = new ExtensionManagementServerService()
        this.webExtensions = new Extensions(
            extensionManagementServerService.webExtensionManagementServer
        )
        this.whenInitialized = this.initialize() // 1087
    }
    initialize() {
        this.queryLocal()
    }
    async queryLocal() { // 1325
        await this.webExtensions.queryInstalled()
    }
} // 3257

// entry point
async function test() {
    const extensionsWorkbenchService = new ExtensionsWorkbenchService()
}

test()
