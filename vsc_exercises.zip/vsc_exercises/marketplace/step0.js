/*
    How VS Code gets info about extensions from the server
*/