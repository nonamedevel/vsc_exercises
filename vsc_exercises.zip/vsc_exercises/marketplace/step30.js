/*
    Add WorkbenchExtensionGalleryService and AbstractExtensionGalleryService
*/
console.log('Step 30')

// src\vs\base\parts\request\common\requestImpl.ts
async function request(options) {
    const res = await fetch(options.url)
    return res
}

// src\vs\platform\request\common\request.ts
class AbstractRequestService {
    async logAndRequest(options, request) {
        const result = await request()
        return result
    }
}

// src\vs\workbench\services\request\browser\requestService.ts
class BrowserRequestService extends AbstractRequestService {
    async request(options) { // 36
        const context = await this.logAndRequest(
            options, 
            () => request(options)
        )
        return context
    }
}

// src\vs\platform\extensionManagement\common\extensionGalleryService.ts
class AbstractExtensionGalleryService {
    constructor() {
        this.requestService = new BrowserRequestService()
    }
    async getExtensionsControlManifest() { // 1799
        this.extensionsControlUrl = 'https://main.vscode-cdn.net/extensions/marketplace.json'
        const context = await this.requestService.request({
			type: 'GET',
			url: this.extensionsControlUrl,
        })
        const result = await context.json() // 1820
        return result
    }
}

// src\vs\workbench\services\extensionManagement\common\extensionGalleryService.ts
class WorkbenchExtensionGalleryService extends AbstractExtensionGalleryService {
}

async function test() {
    const workbenchExtensionGalleryService = new WorkbenchExtensionGalleryService()
    const result = await workbenchExtensionGalleryService.getExtensionsControlManifest()
    console.log(result)
}

test()
