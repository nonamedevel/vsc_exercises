/*
    Starting point
*/
console.log('Step 10')

async function test() {
    const url = 'https://main.vscode-cdn.net/extensions/marketplace.json'
    const res = await fetch(url)
    const data = await res.json()
    console.log(data)
}

test()
