/*
    Starting point
*/

const editor = document.createElement('div')
editor.style.width = '300px'
editor.style.height = '50px'
editor.style.border = '1px solid black'
document.body.append(editor)

const editContext = new EditContext()
editor.editContext = editContext
editContext.addEventListener('textupdate', (event) => {
    console.log(event)
    console.log(
        event.text, 
        event.updateRangeStart, 
        event.updateRangeEnd, 
        event.target.text
    )
})
