/*
    Scenario: User types a character
*/

// src\vs\editor\common\model\pieceTreeTextBuffer\rbTreeBase.ts
class TreeNode { // i4e
    constructor() {
        console.log('TreeNode')
    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeBase.ts
class PieceTreeBase {
    insert() {
        let node = this.rbInsertLeft(null, pieces[0]);
    }
    rbInsertLeft() { // 1847
        const z = new TreeNode(p, NodeColor.Red);
    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeTextBuffer.ts
class PieceTreeTextBuffer {
    applyEdits() { // 243
        const contentChanges = this._doApplyEdits(operations);
    }
    _doApplyEdits() { // 479
        this._pieceTree.insert(op.rangeOffset, op.text, true);
    }
}

// src\vs\editor\common\model\editStack.ts
class EditStack {
    pushEditOperation() {
        const inverseEditOperations = this._model.applyEdits(editOperations, true, reason);
    }
}

// src\vs\editor\common\model\textModel.ts
class TextModel {
    pushEditOperations() {
        this._pushEditOperations()
    }
    _pushEditOperations() { // 1307
        this._commandManager.pushEditOperation()
    }
    applyEdits() { // 1438
        return this._doApplyEdits();
    }
    _doApplyEdits() { // 1458
        this._buffer.applyEdits()
    }
}

// src\vs\editor\common\cursor\cursor.ts
class CursorsController {
    _executeEditOperation() {
        const result = CommandExecutor.executeCommands()
    }
    _executeEdit(callback) { // 509
        callback()
    }
    type() { // 556
		this._executeEdit(() => {
            this._executeEditOperation()
        })
    }
}
class CommandExecutor {
    static executeCommands() { // 759
        this._innerExecuteCommands()
    }
    _innerExecuteCommands() { // 777
        ctx.model.pushEditOperations()
    }
}

// src\vs\editor\common\viewModel\viewModelImpl.ts
class ViewModel {
    constructor() {

    }
    _executeCursorEdit() {
        this._withViewEventsCollector(callback);
    }
    type(text, source) { // 1168
		this._executeCursorEdit(
            eventsCollector => this._cursor.type(eventsCollector, text, source)
        );
	}
    _withViewEventsCollector(callback) { // 1218
		return this._transactionalTarget.batchChanges(() => {
			try {
				const eventsCollector = this._eventDispatcher.beginEmitViewEvents();
				return callback(eventsCollector);
			} finally {
				this._eventDispatcher.endEmitViewEvents();
			}
		});
    }
}

// src\vs\editor\browser\editorExtensions.ts
class Command {
    register() {
		CommandsRegistry.registerCommand({
			id: this.id,
			handler: (accessor, args) => this.runCommand(accessor, args),
			metadata: this.metadata
		});
    }
}

// src\vs\editor\browser\coreCommands.ts
class EditorHandlerCommand extends Command {
    constructor() {

    }
    runCommand() {
        editor.trigger('keyboard', this._handlerId, args)
    }
}

// src\vs\platform\commands\common\commands.ts
class CommandsRegistry {
    static registerCommand() {
        const actualHandler = idOrCommand.handler
        idOrCommand.handler = function (accessor, ...args) {
            validateConstraints(args, constraints);
            return actualHandler(accessor, ...args);
        };
    }
    getCommand() {
        
    }
}

// src\vs\platform\instantiation\common\instantiationService.ts
class InstantiationService {
    invokeFunction(fn) {
        const accessor = {

        }
        fn(accessor)
    }
}

// src\vs\workbench\services\commands\common\commandService.ts
class CommandService {
    constructor(_instantiationService) {
        this._instantiationService = _instantiationService
    }
    executeCommand() {
        this._tryExecuteCommand()
    }
    _tryExecuteCommand() {
        this._instantiationService.invokeFunction()
    }
}

// src\vs\editor\browser\view.ts
class View {
    constructor(commandDelegate) {
        this._viewController = new ViewController(commandDelegate)
        this._editContext = this._instantiateEditContext()
    }
    _instantiateEditContext() {
        return new NativeEditContext(this._viewController)
    }
}

// src\vs\editor\common\editorCommon.ts
const editorCommon = {
    Handler: {
        Type: 'type'
    }
}

// src\vs\editor\browser\widget\codeEditor\codeEditorWidget.ts
class CodeEditorWidget {
    constructor(commandService) {
        this._commandService = commandService
    }
    trigger() { // 1082
        this._type(source, args.text || '');
    }
    _type() { // 1163
        this._modelData.viewModel.type(text, source);
    }
    _attachModel() { // 1698
        const viewModel = new ViewModel(
			{
				batchChanges: (cb) => {
					try {
						this._beginUpdate();
						return cb();
					} finally {
						this._endUpdate();
					}
				},
			}
        )
    }
    _createView() { // 1866
        const commandDelegate = {
            type: (text) => {
                const payload = { text }
                this._commandService.executeCommand(editorCommon.Handler.Type, payload)
            }
        }
        const view = new View(commandDelegate)
    }
}

// src\vs\editor\browser\view\viewController.ts
class ViewController {
    constructor(commandDelegate) {
        this.commandDelegate = commandDelegate
    }
    type(text) {
        this.commandDelegate.type(text)
    }
}

// src\vs\editor\browser\controller\editContext\native\nativeEditContextUtils.ts
function editContextAddDisposableListener(target, type, listener) {
    target.addEventListener(type, listener)
}

// src\vs\editor\browser\controller\editContext\native\editContextFactory.ts
const EditContext = {
    create(window) {
        return new window.EditContext()
    }
}

// src\vs\editor\browser\controller\editContext\native\nativeEditContext.ts
class NativeEditContext {
    constructor(_viewController) { // 74
        this.domNode = {
            domNode: document.createElement('div')
        }
        this.domNode.domNode.className = 'native-edit-context'
        document.body.append(this.domNode.domNode)
        this._viewController = _viewController
        this._editContext = EditContext.create(window);
        this.setEditContextOnDomNode();
        editContextAddDisposableListener(this._editContext, 'textupdate', (e) => {
            this._emitTypeEvent(this._viewController, e)
        })
    }
    setEditContextOnDomNode() { // 346
        this.domNode.domNode.editContext = this._editContext
    }
    _emitTypeEvent(viewController, typeInput) { // 386
        this._onType(viewController, typeInput)
    }
    _onType(viewController, typeInput) { // 423
        viewController.type(typeInput.text)
    }
}

// entry point
function test() {
    const instantiationService = new InstantiationService()
    const commandService = new CommandService(instantiationService)
    const codeEditorWidget = new CodeEditorWidget(commandService)
    codeEditorWidget._createView()
}
test()
