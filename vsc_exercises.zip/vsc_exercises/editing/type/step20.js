
// src\vs\editor\common\model\pieceTreeTextBuffer\rbTreeBase.ts
class TreeNode { // i4e
    constructor() {
        console.log('TreeNode')
    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeBase.ts
class PieceTreeBase {
    insert() {
        let node = this.rbInsertLeft()
    }
    rbInsertLeft() { // 1847
        const z = new TreeNode()
    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeTextBuffer.ts
class PieceTreeTextBuffer {
    constructor() {
        this._pieceTree = new PieceTreeBase()
    }
    applyEdits() { // 243
        const contentChanges = this._doApplyEdits()
    }
    _doApplyEdits() { // 479
        this._pieceTree.insert()
    }
}

// src\vs\editor\common\model\editStack.ts
class EditStack {
    constructor(model) {
        this._model = model
    }
    pushEditOperation() {
        const inverseEditOperations = this._model.applyEdits()
    }
}

// src\vs\editor\common\model\textModel.ts
class TextModel {
    constructor() {
        this._commandManager = new EditStack(new PieceTreeTextBuffer())
    }
    pushEditOperations(beforeCursorState, editOperations, cursorStateComputer) { // 1296
        this._pushEditOperations(beforeCursorState)
    }
    _pushEditOperations() { // 1307
        this._commandManager.pushEditOperation()
    }
    applyEdits() { // 1438
        return this._doApplyEdits()
    }
    _doApplyEdits() { // 1458
        this._buffer.applyEdits()
    }
}

// src\vs\editor\common\cursor\cursor.ts
class CursorsController { // 27
    _executeEditOperation(opResult) { // 350
        const result = CommandExecutor.executeCommands(
            undefined,
            undefined,
            opResult.commands
        )
    }
    _executeEdit(callback) { // 509
        callback()
    }
    type(eventsCollector, text) { // 556
		this._executeEdit(() => {
            const chr = text[0]
            this._executeEditOperation({
                commands: [
                    {
                        b: chr
                    }
                ]
            })
        })
    }
}
class CommandExecutor { // 757
    static executeCommands(model, selectionsBefore, commands) { // 759
        const ctx = {
            model: new TextModel()
        }
        this._innerExecuteCommands(ctx, commands)
    }
    static _innerExecuteCommands(ctx, commands) { // 777
        debugger
        ctx.model.pushEditOperations()
    }
}

// src\vs\editor\common\viewModel\viewModelImpl.ts
class ViewModel {
    constructor(_transactionalTarget) {
        this._cursor = new CursorsController()
        this._transactionalTarget = _transactionalTarget
    }
    _executeCursorEdit(callback) { // 1151
        this._withViewEventsCollector(callback)
    }
    type(text, source) { // 1168
		this._executeCursorEdit(
            eventsCollector => this._cursor.type(eventsCollector, text, source)
        )
	}
    _withViewEventsCollector(callback) { // 1218
		this._transactionalTarget.batchChanges(() => {
            return callback()
		})
    }
}

// src\vs\editor\browser\coreCommands.ts
class EditorHandlerCommand {
    runCommand(accessor, args) {
        const editor = codeEditorWidget // hack
        editor.trigger(undefined, undefined, args)
    }
}

// src\vs\platform\instantiation\common\instantiationService.ts
class InstantiationService {
    invokeFunction(fn, ...args) { // 89
        fn(undefined, ...args)
    }
}

// src\vs\workbench\services\commands\common\commandService.ts
class CommandService {
    constructor(_instantiationService) {
        this._instantiationService = _instantiationService
    }
    executeCommand(id, ...args) { // 52
        this._tryExecuteCommand(id, args)
    }
    _tryExecuteCommand(id, args) { // 92
        this._instantiationService.invokeFunction(
            /*
                We don't use CommandRegistry here because it is the major subject of this lesson
                and analyzed in some other lesson
            */
            EditorHandlerCommand.prototype.runCommand,
            ...args
        )
    }
}

// src\vs\editor\browser\view.ts
class View {
    constructor(commandDelegate) {
        this._viewController = new ViewController(commandDelegate)
        this._editContext = this._instantiateEditContext()
    }
    _instantiateEditContext() {
        return new NativeEditContext(this._viewController)
    }
}

// src\vs\editor\common\editorCommon.ts
const editorCommon = {
    Handler: {
        Type: 'type'
    }
}

// src\vs\editor\browser\widget\codeEditor\codeEditorWidget.ts
class CodeEditorWidget { // 67
    constructor(commandService) {
        this._commandService = commandService
    }
    trigger(source, handlerId, payload) { // 1082
        const args = payload
        this._type(undefined, args.text)
    }
    _type(source, text) { // 1163
        this._modelData.viewModel.type(text)
    }
    _attachModel(model) { // 1698
        const viewModel = new ViewModel({
            batchChanges: (cb) => {
                cb()
            }
        })
        const [view] = this._createView()
        this._modelData = new ModelData(model, viewModel, view)
    }
    _createView() { // 1866
        const commandDelegate = {
            type: (text) => {
                const payload = { text }
                this._commandService.executeCommand(editorCommon.Handler.Type, payload)
            }
        }
        const view = new View(commandDelegate)
        return [view]
    }
}
class ModelData { // 2065
    constructor(model, viewModel, view) {
        this.viewModel = viewModel
        this.view = view
    }
}

// src\vs\editor\browser\view\viewController.ts
class ViewController {
    constructor(commandDelegate) {
        this.commandDelegate = commandDelegate
    }
    type(text) {
        this.commandDelegate.type(text)
    }
}

// src\vs\editor\browser\controller\editContext\native\nativeEditContextUtils.ts
function editContextAddDisposableListener(target, type, listener) {
    target.addEventListener(type, listener)
}

// src\vs\editor\browser\controller\editContext\native\editContextFactory.ts
const EditContext = {
    create(window) {
        return new window.EditContext()
    }
}

// src\vs\editor\browser\controller\editContext\native\nativeEditContext.ts
class NativeEditContext {
    constructor(_viewController) { // 74
        this.domNode = {
            domNode: document.createElement('div')
        }
        this.domNode.domNode.className = 'native-edit-context'
        document.body.append(this.domNode.domNode)
        this._viewController = _viewController
        this._editContext = EditContext.create(window)
        this.setEditContextOnDomNode()
        editContextAddDisposableListener(this._editContext, 'textupdate', (e) => {
            this._emitTypeEvent(this._viewController, e)
        })
    }
    setEditContextOnDomNode() { // 346
        this.domNode.domNode.editContext = this._editContext
    }
    _emitTypeEvent(viewController, typeInput) { // 386
        this._onType(viewController, typeInput)
    }
    _onType(viewController, typeInput) { // 423
        viewController.type(typeInput.text)
    }
}

// entry point
let codeEditorWidget
function test() {
    const instantiationService = new InstantiationService()
    const commandService = new CommandService(instantiationService)
    codeEditorWidget = new CodeEditorWidget(commandService)
    codeEditorWidget._attachModel()

    const editor = codeEditorWidget._modelData.view._editContext.domNode.domNode
    editor.style.width = '300px'
    editor.style.height = '50px'
    editor.style.border = '1px solid black'
}
test()
