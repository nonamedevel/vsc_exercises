/*
    Scenario: User types a character
*/
