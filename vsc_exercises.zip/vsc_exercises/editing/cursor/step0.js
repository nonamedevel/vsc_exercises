
// src\vs\editor\common\cursor\cursorTypeEditOperations.ts

/*
AutoIndentOperation                          (+)
AutoClosingOvertypeOperation                 (+)
AutoClosingOvertypeWithInterceptorsOperation (-)
AutoClosingOpenCharTypeOperation             (+)
CompositionEndOvertypeOperation              (-)
SurroundSelectionOperation                   (+)
InterceptorElectricCharOperation             (+)
SimpleCharacterTypeOperation                 (+)
EnterOperation                               (+)
PasteOperation                               (-)
CompositionOperation                         (-)
TypeWithoutInterceptorsOperation             (-)

*/

// src\vs\editor\common\cursor\cursorTypeOperations.ts
class TypeOperations {
    static typeWithInterceptors(
        isDoingComposition,    // boolean
        prevEditOperationType, // EditOperationType
        config,                // CursorConfiguration
        model,                 // ITextModel
        selections,            // Selection[]
        autoClosedCharacters,  // Range[]
        ch,                    // string
    ) {

    }
}

// src\vs\editor\common\cursor\cursor.ts
class CursorsController { // 27
    _executeEditOperation(opResult) { // 350
        const result = CommandExecutor.executeCommands(
            undefined,
            undefined,
            opResult.commands
        )
    }
    _executeEdit(callback) { // 509
        callback()
    }
    type(eventsCollector, text) { // 556
		this._executeEdit(() => {
            const chr = text[0]
            // this._executeEditOperation({
            //     commands: [
            //         {
            //             b: chr
            //         }
            //     ]
            // })
            this._executeEditOperation(
                TypeOperations.typeWithInterceptors(
                    !!this._compositionState, 
                    this._prevEditOperationType, 
                    this.context.cursorConfig, 
                    this._model, 
                    this.getSelections(), 
                    this.getAutoClosedCharacters(), 
                    chr
                )
            )
        })
    }
    getSelections() {

    }
    getAutoClosedCharacters() {

    }
}
class CommandExecutor { // 757
    static executeCommands(model, selectionsBefore, commands) { // 759
        const ctx = {}
        this._innerExecuteCommands(ctx, commands)
    }
    static _innerExecuteCommands(ctx, commands) { // 777
        console.log(commands)
        // ctx.model.pushEditOperations()
    }
}

// entry point
function test() {
    const cursorsController = new CursorsController()
    cursorsController.type(undefined, 'f')
}
test()
