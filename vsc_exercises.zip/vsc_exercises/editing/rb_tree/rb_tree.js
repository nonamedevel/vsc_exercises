/*

textarea.inputarea.monaco-mouse-cursor-text


*/

// src\vs\editor\common\model\pieceTreeTextBuffer\rbTreeBase.ts
class TreeNode { // i4e
    constructor() {

    }
}
