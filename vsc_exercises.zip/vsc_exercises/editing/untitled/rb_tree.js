// src\vs\editor\common\model\pieceTreeTextBuffer\rbTreeBase.ts



// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeBase.ts
class PieceTreeBase {
    constructor(chunks, eol, eolNormalized) {
        this.create(chunks, eol, eolNormalized)
    }
    create(chunks, eol, eolNormalized) {

    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeTextBuffer.ts
class PieceTreeTextBuffer {
    constructor() {
        this._pieceTree = new PieceTreeBase()
    }
}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeTextBufferBuilder.ts
class PieceTreeTextBufferFactory {
    create() {
        const textBuffer = new PieceTreeTextBuffer()
    }
}

// src\vs\editor\common\model\textModel.ts
function createTextBuffer(value) { // 107
    factory = value
    return factory.create()
}
class TextModel { // 182
    constructor() {
        const { textBuffer, disposable } = createTextBuffer()
    }
}


// src\vs\platform\instantiation\common\instantiationService.ts
class InstantiationService {
    createInstance(ctorOrDescriptor) {
        result = this._createInstance(ctorOrDescriptor)
    }
    _createInstance(ctor) {
        return Reflect.construct(ctor, [])
    }
}


// src\vs\editor\common\services\modelService.ts
class ModelService {
    constructor(_instantiationService) {
        this._instantiationService = _instantiationService
    }
    _createModelData() {
        const model = this._instantiationService.createInstance(TextModel)
    }
    createModel() {
        let modelData = this._createModelData()
    }
}

// src\vs\workbench\common\editor\textEditorModel.ts
class BaseTextEditorModel {
    constructor(modelService) {
        this.modelService = modelService
    }
    createTextEditorModel() {
        this.doCreateTextEditorModel()
    }
    doCreateTextEditorModel() { // 169
        const model = this.modelService.createModel()
    }
}

// src\vs\workbench\services\untitled\common\untitledTextEditorModel.ts
class UntitledTextEditorModel extends BaseTextEditorModel {
    constructor(modelService) {
        super(modelService)
    }
    resolve() {
        this.createTextEditorModel()
    }
}

// entry point
function test() {
    const instantiationService = new InstantiationService()
    const modelService = new ModelService(instantiationService)
    const untitledTextEditorModel = new UntitledTextEditorModel(modelService)
    untitledTextEditorModel.resolve()
}
test()

