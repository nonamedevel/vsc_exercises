/*
    devtools on devtools
    Ctrl + Shift + I
*/

const data = [
    ['seven', 'file171.ts:55'],
    ['twenty_two', 'file5347.ts:333'],
    ['one_hundred_and_three', 'file95159.ts:1366'],
    ['sixteen', 'file83.ts:11616'],
]

function extractCallStack(container) {
    const rawLines = []
    // const rawLines = data
    const uppperBound = container.childElementCount - 1
    for (let i = 1; i < uppperBound; i++) {
        const row = container.children[i]
        const funcName = row.querySelector('.call-frame-title-text')
        const fileName = row.querySelector('.call-frame-location')
        rawLines.push([
            funcName.textContent,
            fileName.textContent,
        ])
    }
    let width = 0
    rawLines.reverse()
    for (let i = 0; i < rawLines.length; i++) {
        const funcName = rawLines[i][0]
        const _width = funcName.length + i
        if (_width > width) {
            width = _width
        }
    }
    width += 2
    const formattedLines = []
    for (let i = 0; i < rawLines.length; i++) {
        const item = rawLines[i]
        const indent = ' '.repeat(i)
        const padding = ' '.repeat(width - i - item[0].length)
        formattedLines.push(indent + item[0] + padding + item[1])
    }
    const result = formattedLines.join('\n')
    console.log(result)
}
extractCallStack($0)
