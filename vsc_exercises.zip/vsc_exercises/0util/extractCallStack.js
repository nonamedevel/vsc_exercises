/*
    devtools on devtools
    Ctrl + Shift + I
*/

const data = [
    ['layout', 'sash.ts:641'],
    ['item', 'splitview.ts:1366'],
    ['U', 'splitview.ts:1366'],
    ['layout', 'splitview.ts:877'],
    ['layout', 'paneview.ts:602'],
    ['layout', 'viewPaneContainer.ts:629'],
    ['layout', 'panecomposite.ts:57'],
    ['layout', 'compositePart.ts:517'],
    ['layout', 'paneCompositePart.ts:605'],
    ['layout', 'sidebarPart.ts:159'],
    ['y', 'gridview.ts:928'],
    ['layout', 'gridview.ts:911'],
    ['layout', 'splitview.ts:285'],
    ['U', 'splitview.ts:1361'],
    ['M', 'splitview.ts:989'],
    ['C', 'event.ts:1202'],
    ['fire', 'event.ts:1233'],
    ['i', 'event.ts:131'],
    ['C', 'event.ts:1202'],
    ['fire', 'event.ts:1233'],
    ['e', 'sash.ts:568'],
    ['C', 'event.ts:1202'],
    ['fire', 'event.ts:1233'],
    ['e', 'event.ts:40'],
]

function extractCallStack(container) {
    const temp = []
    const uppperBound = container.childElementCount - 1
    for (let i = 1; i < uppperBound; i++) {
        const funcName = row.querySelector('.call-frame-title-text')
        const fileName = row.querySelector('.call-frame-location')
        temp.push([
            funcName.textContent,
            fileName.textContent,
        ])
    }
    let width = 0
    for (let i = 0; i < temp.length; i++) {
        const row = container.children[i]
        const _width = funcName.length + i
        if (_width > width) {
            width = _width
        }
    }
    width += 2
    console.log(width)
    width = 40
    const result = []
    for (let i = 0; i < temp.length; i++) {
        const item = temp[i]
        const indent = ' '.repeat(i)
        const padding = ' '.repeat(width - i - item[0].length)
        result.push(indent + item[0] + padding + item[1])
    }
    console.log(result.join('\n'))
}
extractCallStack($0)
