
/*


e                              event.ts:40
 fire                          event.ts:1233
  C                            event.ts:1202
   e                           sash.ts:568
    fire                       event.ts:1233
     C                         event.ts:1202
      i                        event.ts:131
       fire                    event.ts:1233
        C                      event.ts:1202
         M                     splitview.ts:989
          U                    splitview.ts:1361
           layout              splitview.ts:285
            layout             gridview.ts:495
             layout            splitview.ts:877
              U                splitview.ts:1366
               item            splitview.ts:1366
                layout         sash.ts:641
            layout             gridview.ts:911
             y                 gridview.ts:928
              layout           sidebarPart.ts:159
               layout          paneCompositePart.ts:605
                layout         compositePart.ts:517
                 layout        panecomposite.ts:57
                  layout       viewPaneContainer.ts:629
                   layout      paneview.ts:602
                    layout     splitview.ts:877
                     U         splitview.ts:1366
                      item     splitview.ts:1366
                       layout  sash.ts:641
          U                    splitview.ts:1366
           item                splitview.ts:1366
            layout             sash.ts:641

*/


// src\vs\base\common\event.ts
const Event = (function() { // 41
    function map(event, map) { // 130
        return snapshot(
            (listener, thisArgs = null, disposables) => event(
                i => listener.call(thisArgs, map(i)), 
                null, 
                disposables
            )
        )
    }
    function snapshot(event) { // 201
		const emitter = new Emitter()
		return emitter.event
    }
    return {
        map,
        snapshot,
    }
})() // 758
class Emitter { // 995
    constructor(options) {
        this._options = options
    }
    get event() { // 1076
        this._event ??= (callback) => {
            this._listener = callback
            // this._options.onWillAddFirstListener(this) // 1114
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\base\browser\ui\sash\sash.ts
const Orientation = { // 113
    VERTICAL: 0,
    HORIZONTAL: 1,
}
class Sash { // 251

}

// src\vs\base\browser\ui\splitview\splitview.ts
class SplitView { // 427
    constructor() {
        this.doAddView()
    }
    onSashChange() { // 969
        this.layoutViews()
    }
    doAddView() {
        const sash = new Sash()
        const sashEventMapper = this.orientation === Orientation.VERTICAL
            ? (e) => ({ sash, start: e.startY, current: e.currentY, alt: e.altKey })
            : (e) => ({ sash, start: e.startX, current: e.currentX, alt: e.altKey });
        const onChange = Event.map(sash.onDidChange, sashEventMapper)
        const onChangeDisposable = onChange(this.onSashChange, this)
    }
    layoutViews() { // 1353

    }
} // 1504

// src\vs\base\browser\ui\grid\gridview.ts

// src\vs\workbench\browser\parts\sidebar\sidebarPart.ts

// src\vs\workbench\browser\parts\paneCompositePart.ts

// src\vs\workbench\browser\parts\compositePart.ts

// panecomposite.ts

// src\vs\workbench\browser\parts\views\viewPaneContainer.ts

// src\vs\base\browser\ui\splitview\paneview.ts

// entry point
function test() {
    // debugger
    const splitView = new SplitView()
}

test()

