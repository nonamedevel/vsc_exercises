
const sash = document.createElement('div')
sash.style.width = '10px'
sash.style.height = '400px'
sash.style.backgroundColor = 'blue'
sash.style.position = 'absolute'
document.body.append(sash)

sash.addEventListener('mousedown', (event) => {
    console.log(event)
})
sash.addEventListener('mouseup', (event) => {
    console.log(event)
})
sash.addEventListener('mousemove', (event) => {
    console.log(event)
    // sash.style.left = event.offsetX + 'px'
    sash.style.left = '300px'
})

