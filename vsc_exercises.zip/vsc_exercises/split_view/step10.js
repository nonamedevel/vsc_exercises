/*
    Scenario: User resizes panes inside the window
    using a mouse pointer


doAddView() is called 9 times:
horizontal
vertical
vertical // The point of interest
vertical
horizontal
horizontal
horizontal
horizontal
horizontal

*/

// src\vs\base\browser\dom.ts
function addDisposableListener(node, type, handler) { // 161
    node.addEventListener(type, handler)
}
const EventHelper = { // 1145
	stop: (e) => {
		e.preventDefault()
	}
}
function getWindow() {
    return window
}

// src\vs\base\common\event.ts
class Emitter {
    constructor(options) {
        this._options = options
    }
    get event() { // 1076
        this._event ??= (callback) => {
            this._listener = callback
            this._options.onWillAddFirstListener(this) // 1114
        }
        return this._event
    }
    fire(event) { // 1221
        this._listener(event)
    }
}

// src\vs\base\browser\event.ts
class DomEmitter { // 28
    constructor(element, type) {
		const fn = (e) => this.emitter.fire(e)
		this.emitter = new Emitter({
			onWillAddFirstListener: () => element.addEventListener(type, fn),
		})
    }
}


// src\vs\base\browser\ui\sash\sash.ts
const Orientation = { // 113
    VERTICAL: 0,
    HORIZONTAL: 1,
}
class MouseEventFactory { // 175
    onPointerMove() {
        return this.disposables.add(
            new DomEmitter(getWindow(this.el), 'mousemove')
        ).event;
    }
}
class Sash { // 251
    constructor(container) { // 251
        this.el = document.createElement('div') // 416
        this.el.classList.add('monaco-sash')
		container.appendChild(this.el)
        addDisposableListener(
            this.el, 
            'mousedown', 
            e => this.onPointerStart(e, new MouseEventFactory(container))
        )
    }
    onPointerStart(event, pointerEventFactory) {
		const onPointerMove = (e) => {
			EventHelper.stop(e, false)
			const event = {
                startX,
                currentX: e.pageX,
                startY,
                currentY: e.pageY,
            }
			this._onDidChange.fire(event)
		}
        pointerEventFactory.onPointerMove(onPointerMove)
    }
    layout() { // 640
        this.el.style.left = '255px'
    }
} // 684

// src\vs\base\browser\ui\splitview\splitview.ts
class SplitView { // 427
    constructor(container, options) {
        this.orientation = options.orientation // 571

        this.el = document.createElement('div') // 576
        this.el.classList.add('monaco-split-view2')
		this.el.classList.add(
            this.orientation === Orientation.VERTICAL ? 'vertical' : 'horizontal'
        )
		container.appendChild(this.el)

        this.sashContainer = document.createElement('div') // 581
        this.sashContainer.classList.add('sash-container')
        this.el.append(this.sashContainer)

        options.descriptor.views.forEach((viewDescriptor, index) => { // 624
            this.doAddView()
        })
    }
    doAddView() { // 1112
        const sash = new Sash(this.sashContainer)
    }
} // 1504

// entry point
function test() {
    const splitView = new SplitView(document.body, {
        orientation: Orientation.HORIZONTAL,
        descriptor: {
            views: [
                'placeholder'
            ]
        }
    })
}

test()


/*

layout                  sash.ts:641
 item                   splitview.ts:1366
  U                     splitview.ts:1366
   layout               splitview.ts:877
    layout              gridview.ts:495
     layout             splitview.ts:285
      U                 splitview.ts:1361
       M                splitview.ts:989
        C               event.ts:1202
         fire           event.ts:1233
          i             event.ts:131
           C            event.ts:1202
            fire        event.ts:1233
             e          sash.ts:568
              C         event.ts:1202
               fire     event.ts:1233
                e       event.ts:40

*/

function extractCallStack(container) {
    let str = ''
    console.log(container)
    const uppperBound = container.childElementCount - 1
    for (let i = 1; i < uppperBound; i++) {
        const funcName = container.children[i].querySelector('.call-frame-title-text').textContent
        const funcName1 = `${' '.repeat(i - 1)}${funcName.padEnd(24 - i)} `
        const fileName = container.children[i].querySelector('.call-frame-location')
        str += `${funcName1} ${fileName.textContent}\n`
    }
    console.log(str)
}
extractCallStack($0)







