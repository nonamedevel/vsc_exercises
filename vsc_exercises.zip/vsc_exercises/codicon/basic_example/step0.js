/*

src\vs\base\browser\ui\codicons\codicon\codicon.ttf

*/

// C:\vscode-main\src\vs\base\common\codiconsUtil.ts
const _codiconFontCharacters = Object.create(null)
function register(id, fontCharacter) {
    _codiconFontCharacters[id] = fontCharacter
}

// src\vs\base\common\codicons.ts


// src\vs\base\common\codiconsLibrary.ts
const codiconsLibrary = {
	splitHorizontal: register('split-horizontal', 0xeb56),
	splitVertical: register('split-vertical', 0xeb57),
}

const elem = document.createElement('div')
elem.classList.add('example')
document.body.append(elem)

// src\vs\platform\theme\browser\iconsStyleSheet.ts
