
function test1() {
    const elem = document.createElement('div')
    // elem.textContent = '\ueb58'
    elem.textContent = String.fromCharCode(0xeb58)
    elem.classList.add('example')
    document.body.append(elem)
}

/*
    Codicon font provides 530 icons
    (0xea60 - 0xec71)
*/
function test() {
    const container = document.createElement('div')
    container.style.display = 'flex'
    container.style.flexWrap = 'wrap'
    container.style.fontFamily = 'codicon'
    document.body.append(container)
    for (let i = 0xea60; i <= 0xec71; i++) {
        const elem = document.createElement('span')
        elem.textContent = String.fromCharCode(i)
        elem.classList.add(`code-${i.toString(16)}`)
        container.append(elem)
    }
}

test()
