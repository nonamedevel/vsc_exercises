

const elem = document.createElement('div')
elem.classList.add('example')
document.body.append(elem)

