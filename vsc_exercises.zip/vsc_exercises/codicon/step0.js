/*

src\vs\base\browser\ui\codicons\codicon\codicon.ttf

*/