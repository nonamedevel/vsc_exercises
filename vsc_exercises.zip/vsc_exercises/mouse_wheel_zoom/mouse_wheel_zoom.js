/*

"editor.mouseWheelZoom": true

*/

// placeholders
const platform = {isMacintosh: false}

// src\vs\editor\common\config\editorOptions.ts
class SimpleEditorOption {
    constructor(id, name, defaultValue, schema) { // 1190
		this.id = id
		this.name = name
		this.defaultValue = defaultValue
		this.schema = schema
    }
}
class EditorBooleanOption extends SimpleEditorOption { // 1229
    constructor(id, name, defaultValue, schema) {
        super(id, name, defaultValue, schema)
    }
}
function register(option) { // 5720
    return option
}
const EditorOption = { // 5725
    mouseWheelZoom: 84
}
const nls = {
    localize(param1, param2) {
        return param2
    }
}
const EditorOptions = { // 5902
    mouseWheelZoom: register(new EditorBooleanOption(
		EditorOption.mouseWheelZoom, // id
        'mouseWheelZoom', // name
        false, // defaultValue
		{ // schema
			markdownDescription: (function() {
                if (platform.isMacintosh) {
                    return nls.localize(
                        'mouseWheelZoom.mac', 
                        "Zoom the font of the editor when using mouse wheel and holding `Cmd`."
                    )
                }
                return nls.localize(
                    'mouseWheelZoom', 
                    "Zoom the font of the editor when using mouse wheel and holding `Ctrl`."
                )
            })()
		}
	)),
}

// src\vs\base\browser\markdownRenderer.ts
function renderMarkdown(markdown, resolvedOptions, target) { // 184

    const renderedContent = document.createElement('div')

	let outElement
	if (target) {
	} else {
		outElement = renderedContent
	}

    document.body.append(outElement)

    elem = document.createElement('p')
    outElement.append(elem)
    return {
        element: outElement
    }
}

// src\vs\platform\markdown\browser\markdownRenderer.ts
class MarkdownRendererService {
    render(markdown, options, outElement) {
        const resolvedOptions = { ...options }
        const rendered = renderMarkdown(markdown, resolvedOptions, outElement)
        rendered.element.classList.add('rendered-markdown')
        return rendered
    }
}

// src\vs\workbench\contrib\preferences\browser\settingsTree.ts
class AbstractSettingRenderer {
    constructor(_markdownRendererService) {
        this._markdownRendererService = _markdownRendererService
    }
    renderSettingMarkdown() {
        const renderedMarkdown = this._markdownRendererService.render()
        renderedMarkdown.element.classList.add('setting-item-markdown')
    }
}


// entry point
let elem

const markdownRendererService = new MarkdownRendererService()
const abstractSettingRenderer = new AbstractSettingRenderer(markdownRendererService)
abstractSettingRenderer.renderSettingMarkdown()

elem.textContent = EditorOptions.mouseWheelZoom.schema.markdownDescription


