
// src\vs\workbench\browser\parts\paneCompositePart.ts
class AbstractPaneCompositePart {
    updateCompositeBar() {
        let newCompositeBarContainer = this.titleContainer

        const composite = document.createElement('div')
        composite.className = 'composite title'
        document.body.append(composite)

        const compositeBarContainer = document.createElement('div')
        composite.className = 'composite-bar-container'
        composite.append(compositeBarContainer)

        const compositeBar = document.createElement('div')
        compositeBar.className = 'composite-bar'
        compositeBarContainer.append(compositeBar)

        const monacoActionBar = document.createElement('div')
        compositeBar.className = 'monaco-action-bar'
        compositeBar.append(monacoActionBar)

        const actionsContainer = document.createElement('ul')
        compositeBar.className = 'actions-container'
        monacoActionBar.append(actionsContainer)

        const titles = ['Problems', 'Output', 'Terminal']
        for (let i = 0; i < 3; i++) {
            const actionItem = document.createElement('li')
            actionItem.className = 'action-item'
            actionsContainer.append(actionItem)

            const actionLabel = document.createElement('a')
            actionLabel.className = 'action-label'
            actionLabel.textContent = titles[i]
            actionItem.append(actionLabel)
        }
    }
}

const abstractPaneCompositePart = new AbstractPaneCompositePart()
abstractPaneCompositePart.updateCompositeBar()


