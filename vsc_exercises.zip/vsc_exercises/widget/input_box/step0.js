/*

    Scenario: User opens a Profiles editor
    and starts to type into the profile name input
    of an existing or new profile

*/