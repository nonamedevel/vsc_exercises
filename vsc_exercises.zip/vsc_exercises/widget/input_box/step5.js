/*
    Add InputBox
*/
console.log('Step 5')

// src\vs\base\browser\ui\widget.ts
class Widget {
    oninput(domNode, listener) {
        domNode.addEventListener('input', listener)
    }
}

// src\vs\base\browser\ui\inputbox\inputBox.ts
class InputBox extends Widget {
    constructor() {
        super()
        this.input = document.createElement('input') // 145
        document.body.append(this.input) // 145
        this.oninput(this.input, () => this.onValueChange()) // 199
    }
	setPlaceHolder(placeHolder) { // 230
		this.input.setAttribute('placeholder', placeHolder)
	}
    onValueChange() {
        console.log(this.input.value)
    }
}

// entry point
function test() {
    const inputBox = new InputBox()
    inputBox.input.style.display = 'block'
    inputBox.setPlaceHolder('Profile Name')
}

test()
