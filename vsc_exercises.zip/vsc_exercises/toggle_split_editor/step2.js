/*
div.monaco-action-bar
    ul.actions-container
        li.action-item
            a.action-label
*/

const actionBar = document.createElement('div')
actionBar.classList.add('monaco-action-bar')
document.body.append(actionBar)

const actionsContainer = document.createElement('ul')
actionsContainer.classList.add('actions-container')
actionBar.append(actionsContainer)

const actionItem = document.createElement('li')
actionItem.classList.add('action-item')
actionsContainer.append(actionItem)

const actionLabel = document.createElement('a')
actionLabel.classList.add('action-label')
actionItem.append(actionLabel)

// src\vs\base\browser\dom.ts
function addDisposableListener(node, type, handler) { // 161
    node.addEventListener(type, handler)
}
const EventType = { // 1072
    CLICK: 'click',
}

// src\vs\base\browser\ui\actionbar\actionViewItems.ts
class BaseActionViewItem {
    render() { // 114
		addDisposableListener(element, EventType.CLICK, e => {
			this.onClick(e)
		})
    }
}

