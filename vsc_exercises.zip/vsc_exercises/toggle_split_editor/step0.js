/*
    Scenario: User presses the Alt key on the keyboard,
    the button in the top right corner of the window
    (Split Editor Right, Split Editor Down)
    changes its view (vertical to horizontal)
*/