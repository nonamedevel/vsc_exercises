/*
    Starting point
div.monaco-action-bar
    ul.actions-container
        li.action-item
            a.action-label
*/

const actionBar = document.createElement('div')
actionBar.classList.add('monaco-action-bar')
document.body.append(actionBar)

const actionsContainer = document.createElement('ul')
actionsContainer.classList.add('actions-container')
actionBar.append(actionsContainer)

const actionItem = document.createElement('li')
actionItem.classList.add('action-item')
actionsContainer.append(actionItem)
actionItem.addEventListener('click', () => {
    console.log('action-item')
})

const actionLabel = document.createElement('a')
actionLabel.classList.add('action-label')
actionItem.append(actionLabel)

