/*
    src\vs\workbench\contrib\webview\browser\pre\service-worker.js
*/
console.log(123)

self.addEventListener('install', (event) => {
    console.log('SW installed')
    self.skipWaiting()
})

self.addEventListener('activate', (event) => {
    console.log('SW activated')
    event.waitUntil(self.clients.claim())
})

self.addEventListener('fetch', (event) => {
    console.log('fetch', event.request.url)
    if (event.request.url.includes('service_worker/hello.txt')) {
        console.log('inside if')
        event.respondWith(new Response('Hello from Service Worker!', {
            headers: { 'Content-Type': 'text/plain' }
        }))
    }
})
