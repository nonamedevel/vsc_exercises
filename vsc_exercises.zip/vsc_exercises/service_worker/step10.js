
const registerBtn = document.createElement('button')
registerBtn.textContent = 'Register SW'
document.body.append(registerBtn)
registerBtn.addEventListener('click', async () => {
    if ('serviceWorker' in navigator) {
        try {
            const reg = await navigator.serviceWorker.register(
                // 'service_worker/sw.js',
                'service_worker/sw.js',
                // { scope: '/' },
                // { scope: '/service_worker/' },
            )
            console.log(`SW registered: ${reg.scope}`)
        } catch (err) {
            console.log(`Registration failed: ${err}`)
        }
    } else {
        console.log('Service Workers not supported')
    }
})

const testBtn = document.createElement('button')
testBtn.textContent = 'Test /hello'
document.body.append(testBtn)
testBtn.addEventListener('click', async () => {
    // const url = 'http://localhost:8000/service_worker/hello.txt'
    const url = '/service_worker/hello.txt'
    // const url = 'service_worker/hello.txt'
    const res = await fetch(url)
    const text = await res.text()
    console.log(text)
})
